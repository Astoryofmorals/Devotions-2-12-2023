/*:
 * @author Casper Gaming
 * @url https://www.caspergaming.com/plugins/cgmz/itemconditions/
 * @target MZ
 * @plugindesc Restricts Items and Skills from being used in certain maps or
 * battles
 * @help
 * ============================================================================
 * For terms and conditions using this plugin in your game please visit:
 * https://www.caspergaming.com/terms-of-use/
 * ============================================================================
 * Become a Patron to get access to beta/alpha plugins plus other goodies!
 * https://www.patreon.com/CasperGamingRPGM
 * ============================================================================
 * Version: 1.0
 * ----------------------------------------------------------------------------
 * Compatibility: Only tested with my CGMZ plugins.
 * Made for RPG Maker MZ 1.0.0
 * ----------------------------------------------------------------------------
 * Description: This plugin allows you to restrict the player from using
 * certain items or skills in certain maps or against certain troops. For
 * example, an escape rope item that only works in your dungeon maps or an 
 * item that only works in a boss battle.
 * ----------------------------------------------------------------------------
 * Documentation:
 * Item/skill restrictions will be applied by troop ID (if in battle) or by
 * map ID (if not in battle).
 *
 * No restrictions set up in this plugin will be applied if the respective
 * "Lift Restrictions" switch is set to ON.
 *
 * @param Skill Restrictions
 *
 * @param Skills
 * @parent Skill Restrictions
 * @type struct<SkillRestriction>[]
 * @default []
 * @desc Set up skill restrictions here
 *
 * @param Lift Skill Restriction Switch
 * @parent Skill Restrictions
 * @type switch
 * @default 0
 * @desc When this switch is ON, all skill restrictions will be lifted. When OFF, restrictions apply.
 *
 * @param Item Restrictions
 *
 * @param Items
 * @parent Item Restrictions
 * @type struct<ItemRestriction>[]
 * @default []
 * @desc Set up item restrictions here
 *
 * @param Lift Item Restriction Switch
 * @parent Item Restrictions
 * @type switch
 * @default 0
 * @desc When this switch is ON, all item restrictions will be lifted. When OFF, restrictions apply.
*/
/*~struct~SkillRestriction:
 * @param Skill
 * @type skill
 * @default 0
 * @desc The skill to add skill restrictions to
 * 
 * @param Restricted Maps
 * @type number[]
 * @min 1
 * @default []
 * @desc The map IDs to restrict the skill from use
 * 
 * @param Restricted Troops
 * @type troop[]
 * @default []
 * @desc The troop IDs to restrict the skill from use
 */
 /*~struct~ItemRestriction:
 * @param Item
 * @type item
 * @default 0
 * @desc The item to add item restrictions to
 * 
 * @param Restricted Maps
 * @type number[]
 * @min 1
 * @default []
 * @desc The map IDs to restrict the item from use
 * 
 * @param Restricted Troops
 * @type troop[]
 * @default []
 * @desc The troop IDs to restrict the item from use
 */
var Imported = Imported || {};
Imported.CGMZ_LocationConditions = true;
var CGMZ = CGMZ || {};
CGMZ.Versions = CGMZ.Versions || {};
CGMZ.Versions["Item Conditions"] = "1.0";
CGMZ.ItemConditions = CGMZ.ItemConditions || {};
CGMZ.ItemConditions.parameters = PluginManager.parameters('CGMZ_ItemConditions');
CGMZ.ItemConditions.SkillSwitchLiftRestrictions = Number(CGMZ.ItemConditions.parameters["Lift Skill Restriction Switch"]) || 0;
CGMZ.ItemConditions.ItemSwitchLiftRestrictions = Number(CGMZ.ItemConditions.parameters["Lift Item Restriction Switch"]) || 0;
CGMZ.ItemConditions.SkillRestrictions = JSON.parse(CGMZ.ItemConditions.parameters["Skills"]);
CGMZ.ItemConditions.ItemRestrictions = JSON.parse(CGMZ.ItemConditions.parameters["Items"]);
//=============================================================================
// CGMZ_Temp
//-----------------------------------------------------------------------------
// Adds location restriction data to CGMZ Temp
//=============================================================================
//-----------------------------------------------------------------------------
// Add set up item and skill conditions data
//-----------------------------------------------------------------------------
const alias_CGMZ_ItemConditions_createPluginData = CGMZ_Temp.prototype.createPluginData
CGMZ_Temp.prototype.createPluginData = function() {
	alias_CGMZ_ItemConditions_createPluginData.call(this);
	this._itemConditions_skillRestrictions = {};
	this._itemConditions_itemRestrictions = {};
	CGMZ.ItemConditions.SkillRestrictions.forEach((skill) => {
		let tempObj = {};
		tempObj.maps = [];
		tempObj.troops = [];
		const skillObj = JSON.parse(skill);
		const id = Number(skillObj.Skill);
		const maps = JSON.parse(skillObj["Restricted Maps"]);
		const troops = JSON.parse(skillObj["Restricted Troops"]);
		for(let i = 0; i < maps.length; i++) {
			tempObj.maps.push(Number(maps[i]));
		}
		for(let i = 0; i < troops.length; i++) {
			tempObj.troops.push(Number(troops[i]));
		}
		this._itemConditions_skillRestrictions[id] = tempObj;
	});
	CGMZ.ItemConditions.ItemRestrictions.forEach((item) => {
		let tempObj = {};
		tempObj.maps = [];
		tempObj.troops = [];
		const itemObj = JSON.parse(item);
		const id = Number(itemObj.Item);
		const maps = JSON.parse(itemObj["Restricted Maps"]);
		const troops = JSON.parse(itemObj["Restricted Troops"]);
		for(let i = 0; i < maps.length; i++) {
			tempObj.maps.push(Number(maps[i]));
		}
		for(let i = 0; i < troops.length; i++) {
			tempObj.troops.push(Number(troops[i]));
		}
		this._itemConditions_itemRestrictions[id] = tempObj;
	});
};
//-----------------------------------------------------------------------------
// Get item restrictions
//-----------------------------------------------------------------------------
CGMZ_Temp.prototype.getItemConditions = function() {
	return this._itemConditions_itemRestrictions;
};
//-----------------------------------------------------------------------------
// Get skill restrictions
//-----------------------------------------------------------------------------
CGMZ_Temp.prototype.getSkillConditions = function() {
	return this._itemConditions_skillRestrictions;
};
//=============================================================================
// Game_BattlerBase
//-----------------------------------------------------------------------------
// Additional checking for correct map to use skill/item
//=============================================================================
//-----------------------------------------------------------------------------
// Alias. Also check map
//-----------------------------------------------------------------------------
const alias_CGMZ_ItemConditions_canUse = Game_BattlerBase.prototype.canUse;
Game_BattlerBase.prototype.canUse = function(item) {
	const origReturn = alias_CGMZ_ItemConditions_canUse.call(this, item);
	if(origReturn) {
		if(DataManager.isSkill(item) && 
		  (CGMZ.ItemConditions.SkillSwitchLiftRestrictions <= 0 || !$gameSwitches.value(CGMZ.ItemConditions.SkillSwitchLiftRestrictions))) {
			return this.CGMZ_ItemConditions_CheckSkillRestrictions(item);
		} else if(DataManager.isItem(item) && 
				 (CGMZ.ItemConditions.ItemSwitchLiftRestrictions <= 0 || !$gameSwitches.value(CGMZ.ItemConditions.ItemSwitchLiftRestrictions))) {
			return this.CGMZ_ItemConditions_CheckItemRestrictions(item);
		}
	}
    return origReturn;
};
//-----------------------------------------------------------------------------
// Check items for additional restrictions
//-----------------------------------------------------------------------------
Game_BattlerBase.prototype.CGMZ_ItemConditions_CheckItemRestrictions = function(item) {
	if($gameParty.inBattle()) {
		return this.CGMZ_ItemConditions_checkBattleRestrictions(item, $cgmzTemp.getItemConditions());
	}
	return this.CGMZ_ItemConditions_checkMapRestrictions(item, $cgmzTemp.getItemConditions());
};
//-----------------------------------------------------------------------------
// Check skills for map restrictions
//-----------------------------------------------------------------------------
Game_BattlerBase.prototype.CGMZ_ItemConditions_CheckSkillRestrictions = function(skill) {
	if($gameParty.inBattle()) {
		return this.CGMZ_ItemConditions_checkBattleRestrictions(skill, $cgmzTemp.getSkillConditions());
	}
	return this.CGMZ_ItemConditions_checkMapRestrictions(skill, $cgmzTemp.getSkillConditions());
};
//-----------------------------------------------------------------------------
// Check battle restrictions for skills or items
//-----------------------------------------------------------------------------
Game_BattlerBase.prototype.CGMZ_ItemConditions_checkBattleRestrictions = function(item, itemConditions) {
	if(itemConditions[item.id] && itemConditions[item.id].troops.includes($gameTroop._troopId)) {
		return false;
	}
	return true;
};
//-----------------------------------------------------------------------------
// Check map restrictions for skills or items
//-----------------------------------------------------------------------------
Game_BattlerBase.prototype.CGMZ_ItemConditions_checkMapRestrictions = function(item, itemConditions) {
	if(itemConditions[item.id] && itemConditions[item.id].maps.includes($gameMap.mapId())) {
		return false;
	}
	return true;
};