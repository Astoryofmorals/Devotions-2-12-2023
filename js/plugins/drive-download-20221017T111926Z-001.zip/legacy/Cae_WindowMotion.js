// ==================================================
// Cae_WindowMotion.js
// ==================================================

/**
 * @file Cae_WindowMotion.js (RMMZ)
 * Options for moving game windows during play.
 * @author Caethyril
 * @version 1.2
 */

//#region Plugin Header
/*:
 * @target MZ
 * @plugindesc v1.2 - Define custom game window movements.
 * @author Caethyril
 * @url https://forums.rpgmakerweb.com/index.php?threads/caethyrils-mz-plugins.125657/
 * 
 * @help Features:
 *   Specify passive/automatic movement formulae for any game window.
 *   Movement formulae are JavaScript processed in the window's context.
 *   Local variable f = frames since window initialisation.
 *   Formulae should include a return statement!
 *   The value returned (px) will be added to the default position.
 *   Note that this plugin does NOT add data to save files.
 * 
 *   You can also use plugin commands to move windows actively, mid-game.
 *   Local variable t = 0 to 1 = percentage of movement time elapsed.
 * 
 *   All formulae are evaluated in the context of the moving window.
 * 
 * Example formulae (passive movement):
 *   Sine wave:
 *     return 20 * Math.sin(Math.PI * f/120);
 *   Back and forth (linear):
 *     return (f%120 >= 60 ? 120-f%120 : f%60) / 2;
 *   Ease in (quadratic, from top):
 *     return -500 / (f/90)**2;
 *   Ease in (exponential, from bottom):
 *     return 5 * Math.pow(1.08, 80 - f/0.9);
 * 
 * Example formulae (active movement):
 *   Linear:
 *     return t;
 *   Quarter-sine:
 *     return Math.sin(t * Math.PI / 2);
 *   Delayed linear:
 *     return t < 0.5 ? 0 : 2 * (t - 0.5);
 * 
 * Plugin Commands:
 *   Move To - move a specific window that is on the current scene;
 *           - destination can be relative to current position;
 *           - can specify transition time and transit/easing curve.
 *             - curve is a function from [0,1]->[0,1]
 *           - persistent offset is stored when the transition completes.
 *   Reset   - move a moved window back to its original position;
 *           - can specify transition time and transit curve, as above.
 *
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
 * Terms of use:
 *   This plugin is free to use and/or modify, under these conditions:
 *     - None of the original plugin header is removed.
 *     - Credit is given to Caethyril for the original work.
 * 
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
 * Compatibility:
 *   Aliases for specified windows: initialize, update.
 *   Also adds new properties to these windows (see the plugin parameters).
 *   This plugin does not add data to save files.
 * 
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
 * Changelog:
 *   v1.2 (2020-08-30): Fixed - careless error in parameter parsing! v_v
 *   v1.1 (2020-08-22): Can now specify active transition duration as an eval.
 *   v1.0 (2020-08-21): Initial release! Rewrite of RMMV version.
 * 
 * @command Move To
 * @desc Adjust the base position of a given window during play.
 * 
 * @arg Reference
 * @type combo
 * @option _messageWindow
 * @option _commandWindow
 * @option _scrollTextWindow
 * @option _goldWindow
 * @option _nameBoxWindow
 * @option _choiceListWindow
 * @option _numberInputWindow
 * @option _eventItemWindow
 * @option _mapNameWindow
 * @option _logWindow
 * @option _statusWindow
 * @option _partyCommandWindow
 * @option _actorCommandWindow
 * @option _helpWindow
 * @option _skillWindow
 * @option _itemWindow
 * @option _actorWindow
 * @option _enemyWindow
 * @desc The window instance to move. Interpreted as a member of the current scene.
 * @default _messageWindow
 * 
 * @arg Axis
 * @type combo
 * @option X
 * @option Y
 * @desc The coordinate to adjust.
 * @default X
 * 
 * @arg JS: Target
 * @type string
 * @desc JavaScript eval: the new value for this coordinate.
 * Evaluated in the context of the reference window.
 * @default 0
 * 
 * @arg Operator
 * @type combo
 * @option Set
 * @option Add
 * @option Sub
 * @option Mul
 * @option Div
 * @option Mod
 * @desc How to apply the new value relative to the current one.
 * @default Set
 * 
 * @arg JS: Frames
 * @type string
 * @desc JavaScript eval: the duration of the transition, in frames. Minimum 1.
 * @default 1
 * 
 * @arg JS: Transit Curve
 * @type multiline_string
 * @desc JavaScript function body: return position (0 = start, 1 = end).
 * 1 argument: t = fraction of transit time elapsed, from 0 to 1.
 * @default return t;  // linear
 * 
 * @command Reset
 * @desc Moves a given window back to its original position.
 * 
 * @arg Reference
 * @type combo
 * @option _messageWindow
 * @option _commandWindow
 * @option _scrollTextWindow
 * @option _goldWindow
 * @option _nameBoxWindow
 * @option _choiceListWindow
 * @option _numberInputWindow
 * @option _eventItemWindow
 * @option _mapNameWindow
 * @option _logWindow
 * @option _statusWindow
 * @option _partyCommandWindow
 * @option _actorCommandWindow
 * @option _helpWindow
 * @option _skillWindow
 * @option _itemWindow
 * @option _actorWindow
 * @option _enemyWindow
 * @desc The window instance to move.
 * (Relative to current scene.)
 * @default _messageWindow
 * 
 * @arg Axis
 * @type combo
 * @option All
 * @option X
 * @option Y
 * @desc The coordinate to adjust.
 * @default All
 * 
 * @arg JS: Frames
 * @type string
 * @desc JavaScript eval: the duration of the transition, in frames. Minimum 1.
 * @default 1
 * 
 * @arg JS: Transit Curve
 * @type multiline_string
 * @desc Function body: return position (0 = start, 1 = end).
 * 1 argument: t = fraction of transit time elapsed, from 0 to 1.
 * @default return t;  // linear
 * 
 * @param Passive Movement
 * @type struct<WindowMoveFormula>[]
 * @desc List of applicable windows and their passive/automatic movement formulae.
 * @default []
 *
 * @param --- Advanced ---
 * @type select 
 * @desc Advanced internal configuration options.
 *
 * @param Property: Frame Count
 * @parent --- Advanced ---
 * @type string
 * @desc Name of the property used to remember the number of frames for which applicable windows have been open.
 * @default _moveFrameCount
 *
 * @param Property: Base X
 * @parent --- Advanced ---
 * @type string
 * @desc Name of the property used to remember the base x-position of the window before offsets.
 * @default _moveBaseX
 *
 * @param Property: Base Y
 * @parent --- Advanced ---
 * @type string
 * @desc Name of the property used to remember the base y-position of the window before offsets.
 * @default _moveBaseY
 * 
 * @param Property: Transit Data
 * @parent --- Advanced ---
 * @type string
 * @desc Name of the property used to store the current transition data (initiated by Move To plugin command).
 * @default _moveTransitData
 * 
 * @param Property: Offset X
 * @parent --- Advanced ---
 * @type string
 * @desc Name of the property used to remember the persistent x-offset of the window from the base position.
 * @default _moveOffsetX
 * 
 * @param Property: Offset Y
 * @parent --- Advanced ---
 * @type string
 * @desc Name of the property used to remember the persistent y-offset of the window from the base position.
 * @default _moveOffsetY
 */
//========================================
/*~struct~WindowMoveFormula:
 * @param Constructor
 * @type combo
 * @option Window_Base
 * @option Window_GameEnd
 * @option Window_MapName
 * @option Window_Message
 * @option Window_NameEdit
 * @option Window_NameInput
 * @option Window_Options
 * @option Window_ScrollText
 * @option Window_ShopNumber
 * @option Window_TitleCommand
 * @option Window_BattleLog
 * @option Window_PartyCommand
 * @option Window_ActorCommand
 * @option Window_BattleStatus
 * @option Window_BattleActor
 * @option Window_BattleEnemy
 * @option Window_BattleSkill
 * @option Window_BattleItem
 * @desc The window constructor. Case-sensitive!
 * @default Window_Message
 *
 * @param JS: Formula X
 * @type multiline_string
 * @desc Formula for this window's x-position offset.
 * Use f for frame count since the window was opened.
 * @default return 0;
 *
 * @param JS: Formula Y
 * @type multiline_string
 * @desc Formula for this window's y-position offset.
 * Use f for frame count since the window was opened.
 * @default return 0;
 */
//#endregion Plugin Header

(() => {
'use strict';

    const NAMESPACE   = 'WindowMotion';
    const PLUGIN_NAME = 'Cae_' + NAMESPACE;
    const ERR_PRE     = PLUGIN_NAME + '.js ';
    const ERR_NOPARAM = ERR_PRE + 'could not find its parameters!\nCheck the plugin is named correctly and try again.';
    const ERR_FCTBODY = ERR_PRE + '%1 formula error: %2';
    const ERR_WATWIN  = ERR_PRE + 'window "%1" not found! Could not apply movement formulae.';
    const ERR_DUPE    = ERR_PRE + 'definition for "%1" movement formulae already exists!';

    const FUNCSPACE = 'CAE.' + NAMESPACE;       // Modularity for function constructors
    const AXES      = ['X','Y'];                // ...it's prettier this way

    window.CAE = window.CAE || {};              // Author namespace

    (($, U) => {

        Object.defineProperty($, 'VERSION', { value: 1.2 });    // Version declaration
        window.Imported = window.Imported || {};                // Import namespace
        Imported[PLUGIN_NAME] = $.VERSION;                      // Import declaration

        /** Intial value for frame count of passive window motion. */
        $.INIT_FRAME = 0;

    // ======== Parameter stuff ======== //
        
        void (p => {

            if (!p) { SceneManager.showDevTools(); throw new Error(ERR_NOPARAM); };

            $.w = JSON.parse(p['Passive Movement']).map(JSON.parse);

            Object.defineProperty($, 'PFC', { value: p['Property: Frame Count']  || '_moveFrameCount' });
            Object.defineProperty($, 'PBX', { value: p['Property: Base X']       || '_moveBaseX' });
            Object.defineProperty($, 'PBY', { value: p['Property: Base Y']       || '_moveBaseY' });
            Object.defineProperty($, 'PTD', { value: p['Property: Transit Data'] || '_moveTransitData' });
            Object.defineProperty($, 'POX', { value: p['Property: Offset X']     || '_moveOffsetX' });
            Object.defineProperty($, 'POY', { value: p['Property: Offset Y']     || '_moveOffsetY' });

        })($.params = PluginManager.parameters(PLUGIN_NAME));
    
    // ======== Utility (share) ======== //
    
        void (f => { if (U[f]) return;
            /**
             * @param {Number} a - operand 1 (left)
             * @param {Number} b - operand 2 (right)
             * @param {String} op - operator: SET, ADD, SUB, MUL, DIV, or MOD
             * @returns {Number} Result of a op b.
             */
            U[f] = function(a, b, op) {
                switch (String(op || '').toUpperCase()) {
                    case 'SET': return b;
                    case 'ADD': return a + b;
                    case 'SUB': return a - b;
                    case 'MUL': return a * b;
                    case 'DIV': return a / b;
                    case 'MOD': return a.mod(b);
                    default:    return a;
                }
            };
        })('operate');

        void (f => { if (U[f]) return;
            /**
             * @param {String} text - input text for eval
             * @param {Number} dFault - default value, returned on error or non-numerical eval
             * @param {Number} base - base for parseInt
             * @returns {Number} Eval of text coerced to integer, else given default value.
             */
            U[f] = function(text = '', dFault = 0, base = 10) {
                try {
                    const res = eval(text);
                    if (isNaN(res)) throw new Error('Not a number:' + res);
                    return parseInt(res, base);
                } catch (ex) {
                    console.error('Eval error:\n' + text + '\n\n' + ex);
                    return dFault;
                }
            };
        })('tryEvalInt');

    // ======== Utility (local) ======== //

        // Keys for alias methods.
        $.aliasKey = {
            /** 
             * @param {String} c - Constructor name
             * @returns {String} Alias property key for initialize method.
             */
            init: function(c) { return c + '_initialize'; },
            /** 
             * @param {String} c - Constructor name
             * @returns {String} Alias property key for update method.
             */
            update: function(c) { return c + '_update'; }
        };

        /**
         * Returns a blank passive movement record for the specified window.
         * Used as a failsafe for applying transitions.
         * @param {String} c - Constructor name
         * @returns {{"Constructor":String,"JS: Formula X":String,"JS: Formula Y":String}} Blank record.
         */
        $.mkBlank = function(c) { return { 'Constructor': c, 'JS: Formula X': 'return 0;', 'JS: Formula Y': 'return 0;' }; };

        // Function body text generators.
        $.fctMsg = {
            /**
             * @param {String} body - Function body text
             * @return {String} IIFE text invoked in "this" context.
             */
            iife: function(body) {
                return '((function() { ' + body + ' }).call(this) || 0)';
            },
            /**
             * Reference to the relevant axis position of "this".
             * @param {String} axis - Relevant axis: X or Y
             * @returns {String} Relevant window position property reference text.
             */
            prop: function(axis) {
                return 'this.' + axis.toLowerCase();
            },
            /**
             * Returns "this" passive movement formula text.
             * Initial value + passive move offset.
             * @param {String} axis - Relevant axis: X or Y
             * @param {String} body - Function body text
             * @returns {String} Passive movement formula text.
             */
            passive: function(axis, body) {
                return 'this[' + FUNCSPACE + '.PB' + axis + '] + ' + this.iife(body);
            },
            /**
             * Returns persistent positional offset due to completed active transitions (cf plugin command Move To)
             * @param {String} axis - Relevant axis: X or Y
             */
            offset: function(axis) {
                return 'this[' + FUNCSPACE + '.PO' + axis.toUpperCase() + ']';
            },
            /**
             * Returns "this" active (transition) movement formula text.
             * Transit function (if it exists on "this") scaled from [0, 1] -> [0, b-a].
             * @param {String} axis - Relevant axis: X or Y
             * @returns {String} Active movement formula text.
             */
            active: function(axis) {
                const FORM = 'this[' + FUNCSPACE + '.PTD]?.%1' + axis.toLowerCase();
                const CURVE = FORM.format('c');     // Nobody knows how DRY I am >_>
                let res = '(' + CURVE + ' ? ' + CURVE + '()' + ' * (' + FORM.format('b') + ' - ' + FORM.format('a') + ') : 0)';
                return res + ' + ' + this.offset(axis);
            },
            /**
             * Generate function body to apply "this" passive and active/transit offsets for one axis.
             * @param {String} axis - Relevant axis: X or Y
             * @param {String} core - Passive movement formula text.
             * @returns {String} Function body text applying passive & active offsets for one axis.
             */
            full: function(axis, core) {
                const POFF = 'this[' + FUNCSPACE + '.PO' + axis.toUpperCase() + ']';
                const DATA = 'this[' + FUNCSPACE + '.PTD]';
                const FORM = DATA + '.%1' + axis.toLowerCase();
                let res = this.prop(axis) + ' = ' + this.passive(axis, core) + ' + ' + this.active(axis) + ';'
                // Clear transit function if complete
                res += '\nif (' + DATA + '?.c' + axis.toLowerCase() + ') {\n\t';
                res += FORM.format('t') + '++;\n\t';
                res += 'if (' + FORM.format('t') + ' === ' + FORM.format('T') + ') {\n\t\t';
                res += POFF + ' += ' + FORM.format('b') + ' - ' + FORM.format('a') + ';\n\t\t';
                res += '["a","b","c","t","T"].forEach(p => delete ' + DATA + '["%1' + axis.toLowerCase() + '".format(p)]);\n\t}\n}';
                return res;
            }
        };
        
        /**
         * @param {{"Constructor":String,"JS: Formula X":String,"JS: Formula Y":String}} o - Window passive movement record
         * @returns {String} Full update function body text for both axes.
         */
        $.mkBody = function(o) {
            return AXES.reduce((a, c) => a + $.fctMsg.full(c, o['JS: Formula ' + c]) + '\n', '');
        };

        /**
         * Initialises this plugin's passive move params on specified instance.
         * @param {Object} o - Object reference
         */
        $._initPos = function(o) {
            o[$.PFC] = o[$.PFC] || $.INIT_FRAME;
            o[$.PBX] = o[$.PBX] || o.x;
            o[$.PBY] = o[$.PBY] || o.y;
            o[$.POX] = o[$.POX] || 0;
            o[$.POY] = o[$.POY] || 0;
        };

        // Higher-level function body text generation methods.
        $.mkNew = {
            /**
             * @param {String} c - Constructor name
             * @param {Window} w - Window reference
             * @param {{"Constructor":String,"JS: Formula X":String,"JS: Formula Y":String}} o - Window passive movement record
             * @returns {Function} Alias for initialize method.
             */
            init: function(c, w, o) {
                return function() {
                    $.alias[$.aliasKey.init(c)].apply(this, arguments);
                    $._initPos(this);
                };
            },
            /**
             * @param {String} c - Constructor name
             * @param {Window} w - Window reference
             * @param {{"Constructor":String,"JS: Formula X":String,"JS: Formula Y":String}} o - Window passive movement record
             * @returns {Function} Alias for update method.
             */
            update: function(c, w, o) {
                const f = 'this[' + FUNCSPACE + '.PFC]';
                let res = FUNCSPACE + '.alias.' + $.aliasKey.update(c) + '.apply(this, arguments);\n';
                res += 'const f = ' + f + ';\n';
                res += $.mkBody(o);
                res += f + '++;';
                return new Function(this.wrapTry(res, c));
            },
            /**
             * @param {String} src - Function body text
             * @param {String} axis - Relevant axis: x or y
             * @returns {Function} Transit curve function for "this".
             */
            offCurve: function(src, axis) {
                const DATA = 'this[' + FUNCSPACE + '.PTD]';
                const FORM = DATA + '.%1' + axis;
                let res = 'let T = ' + FORM.format('T') + ';\n';
                res += 'let t = ' + FORM.format('t') + ' / T;\n'
                res += src;
                return new Function(this.wrapTry(res, 'offset curve'));
            },
            /**
             * @param {String} body - Function body text
             * @param {String} errRef - Used for error message header if an error is caught
             * @returns {String} Function body text wrapped inside a try-catch statement.
             */
            wrapTry: function(body, errRef) {
                let res = 'try {\n\t' + body.replace(/\n/g, '\n\t') + '\n';
                res += '} catch (ex) {\n\tconsole.error("' + ERR_FCTBODY + '".format("' + errRef + '", ex));\n};';
                return res;
            }
        };

        // Alias application methods!
        $.mkAlias = {
            /**
             * Generate and apply all relevant aliases for specified window.
             * @param {String} c - Constructor name
             * @param {{"Constructor":String,"JS: Formula X":String,"JS: Formula Y":String}} o - Window passive movement record
             */
            all: function(c, o) {
                return $.mkAlias.init(c, o) && $.mkAlias.update(c, o);
            },
            /**
             * Generate and apply initialize alias for specified window.
             * @param {String} c - Constructor name
             * @param {{"Constructor":String,"JS: Formula X":String,"JS: Formula Y":String}} o - Window passive movement record
             */
            init: function(c, o) {
                const w = window[c];
                $.alias[$.aliasKey.init(c)] = w.prototype.initialize;
                return w.prototype.initialize = $.mkNew.init(c, w, o);
            },
            /**
             * Generate and apply update alias for specified window.
             * @param {String} c - Constructor name
             * @param {{"Constructor":String,"JS: Formula X":String,"JS: Formula Y":String}} o - Window passive movement record
             */
            update: function(c, o) {
                const w = window[c];
                $.alias[$.aliasKey.update(c)] = w.prototype.update;
                return w.prototype.update = $.mkNew.update(c, w, o);
            }
        };

        /**
         * @param {String} c - Constructor name
         * @returns {Boolean} True iff this plugin has an alias defined for the specified constructor name.
         */
        $.hasAlias = function(c) { return $.alias[$.aliasKey.init(c)]; };

        /**
         * Sets properties on specified instance, referenced by update alias for active movement.
         * @param {{"Constructor":String,"JS: Formula X":String,"JS: Formula Y":String}} o - Window passive movement record
         * @param {Number} a - Starting position
         * @param {Number} v - Target position
         * @param {String} p - Operator used to apply target position
         *                   - SET, ADD, SUB, MUL, DIV, MOD
         * @param {Number} t - Transit time
         * @param {String} c - Transit curve function body text
         */
        $.applyTransit = function(o = {}, a, v, p, t, c) {
            const D = o[$.PTD] = o[$.PTD] || {};
            $._initPos(o);
            D['a' + a] = o[a];                              // start {px}
            D['b' + a] = U.operate(o[a], v, p);             // end {px}
            D['T' + a] = t;                                 // transit time {frames}
            D['t' + a] = 0;                                 // elapsed time {frames}
            D['c' + a] = $.mkNew.offCurve(c, a).bind(o);    // transit curve [0, 1] -> [0, 1]
            return true;
        };

    // ======== Plugin Commands ======== //
    
        $.com = {
            validate: function(args) {
                const r = args.Reference;
                if (!r) return '';
                const w = SceneManager._scene[r];
                if (!w) return '';
                const c = w.constructor.name;
                if (!c) return '';
                const a = String(args.Axis || '').toLowerCase();
                if (!a) return '';
                return [w, a, c];
            },
            /**
             * Start moving given window instance to given location over given time along given curve.
             * @param {{"Reference":string,"Axis":string,"JS: Target":string,"Operator":string,"JS: Frames":string,"JS: Transit Curve":string}} args - Plugin command arguments
             */
            moveTo: function(args) {
                const [w, a, c] = $.com.validate(args);
                if (!w) return;
                if (!$.hasAlias(c)) $.mkAlias.all(c, $.mkBlank(c));
                const v = U.tryEvalInt.call(w, args['JS: Target'])
                const p = args['Operator'];
                const t = Math.max(U.tryEvalInt.call(w, args['JS: Frames']), 1);
                const u = args['JS: Transit Curve'];
                return $.applyTransit(w, a, v, p, t, u);
            },
            /**
             * If given window instance has been moved by this plugin, reset it to its original position.
             * @param {{"Reference":string,"Axis":string,"JS: Target":string,"Operator":string,"JS: Frames":string,"JS: Transit Curve":string}} args - Plugin command arguments
             */
            resetPos: function(args) {
                const [w, a, c] = $.com.validate(args);
                if (!w) return;
                if (!$.hasAlias(c)) return;   // window was not moved by this plugin
                if (a === 'all') return AXES.forEach(ax => {
                    const args2 = Object.fromEntries(Object.entries(args));     // ew
                    args2.Axis = ax;
                    $.com.resetPos(args2);
                });
                const v = w[$['PB' + a.toUpperCase()]];
                const p = 'SET';
                const t = Math.max(U.tryEvalInt.call(w, args['JS: Frames']), 1);
                const u = args['JS: Transit Curve'];
                return $.applyTransit(w, a, v, p, t, u);
            }
        };
        PluginManager.registerCommand(PLUGIN_NAME, 'Move To', $.com.moveTo);
        PluginManager.registerCommand(PLUGIN_NAME, 'Reset', $.com.resetPos);

    // ========== Alterations ========== //

        $.alias = $.alias || {};        // This plugin's alias namespace

        // Apply aliases for all windows with passive movement defined in the plugin parameters.
        $.w.forEach(o => {
            const c = o['Constructor'];
            if (!window[c]) console.error(ERR_WATWIN.format(c));
            else if ($.hasAlias(c)) console.error(ERR_DUPE.format(c));
            else $.mkAlias.all(c, o);
        });

    })(CAE[NAMESPACE] = CAE[NAMESPACE] || {}, CAE.Utils = CAE.Utils || {});

})();