// ==================================================
// CaeF_RestoreRouteFix.js
// ==================================================

/**
 * @file CaeF_RestoreRouteFix.js (RMMZ)
 * Fixes restore move route index skip bug in core scripts before v1.2.1.
 * @author Caethyril
 * @version 1.1
 */

//#region Plugin header
/*:
 * @target MZ
 * @plugindesc v1.1 - Fixes pre-v1.2.1 core script bug: restore move route index skip.
 * @author Caethyril
 * @url https://forums.rpgmakerweb.com/index.php?threads/125657/
 * 
 * @help This bug is present in RMMZ's core scripts until v1.2.1.
 * 
 * Bug explanation:
 *   By default when a move route ends, the auto move route is reinstated.
 *   It should continue where it left off...
 *   However, one move command is always skipped.
 *   This can cause unexpected movement, e.g. broken patrol loops.
 * 
 * Fix:
 *   This plugin patches the bug by reducing the move index by 1 on restore.
 *   Core scripts v1.2.1 implement a safer fix via isMovementSucceeded.
 *
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
 * Terms of use:
 *   Use however you like!
 * 
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
 * Compatibility:
 *   Aliases:   Game_Character:
 *                restoreMoveRoute
 *   This plugin does not add data to save files.
 * 
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
 * Changelog:
 *   v1.1 (2021-04-08): Now disabled in v1.2.1+, updated plugin help.
 *   v1.0 (2020-08-21): Initial release! Rewrite of RMMV version.
 */
//#endregion

(function() {
'use strict';

    if (Utils.checkRMVersion("1.2.1")) return;  // disable in 1.2.1+

    const NAMESPACE   = 'RestoreRouteFix';
    const PLUGIN_NAME = 'CaeF_' + NAMESPACE;

    window.Imported ||= {};
    Imported[PLUGIN_NAME] = 1.1;

    // Alias! Counter the extra +1 to move index that is about to happen.
    void (alias => {
        Game_Character.prototype.restoreMoveRoute = function() {
            alias.apply(this, arguments);
            this._moveRouteIndex--;  // not so fast!
        };
    })(Game_Character.prototype.restoreMoveRoute);

})();