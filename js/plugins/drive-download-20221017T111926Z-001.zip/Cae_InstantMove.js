// ==================================================
// Cae_InstantMove.js
// ==================================================

/**
 * @file Cae_InstantMove.js (RMMZ)
 * Remove smooth transition of characters between tiles.
 * @author Caethyril
 * @version 1.1
 */

//#region Plugin header
/*:
 * @target MZ
 * @plugindesc v1.1 - No move lerping: map sprites move instantly from tile to tile.
 * @author Caethyril
 * @url https://forums.rpgmakerweb.com/index.php?threads/caethyrils-mz-plugins.125657/
 * 
 * @help Features:
 *   Removes the smooth transition of characters from one tile to the next.
 *   Adds a minimum wait time between consecutive moves.
 *   This wait time is the sum of two values:
 *    - move speed wait: represents travel time
 *    - frequency wait: additional stop time (events)
 *   The formulae for these can be customised in the plugin parameters~
 * 
 *   You can toggle this movement in-game via a switch (see plugin parameters).
 *
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
 * Terms of use:
 *   This plugin is free to use and/or modify, under these conditions:
 *     - None of the original plugin header is removed.
 *     - Credit is given to Caethyril for the original work.
 * 
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
 * Compatibility:
 *   Overrides: Game_CharacterBase:
 *                distancePerFrame
 *   Aliases:   Game_CharacterBase:
 *                updateMove, isMoving
 *   Defines:   Game_CharacterBase:
 *                _moveWait property (customisable)
 *   This plugin does not add data to save files.
 * 
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
 * Changelog:
 *   v1.1 (2020-08-30): Added - plugin features can be linked to a game switch.
 *   v1.0 (2020-08-23): Initial release! Rewrite of RMMV version.
 * 
 * @param Enable Switch
 * @type switch
 * @desc If 0, Instant Move is always on.
 * Otherwise, Instant Move is on when this switch is on.
 * @default 0
 * 
 * @param JS: Speed Wait
 * @type multiline_string
 * @desc JavaScript: formula for wait time from move speed.
 * Default: return 2 ** (8 - speed);
 * @default return 2 ** (8 - speed);
 *
 * @param JS: Frequency Wait
 * @type multiline_string
 * @desc JavaScript: formula for wait time from frequency.
 * Default: return 30 * (5 - frequency);
 * @default return 30 * (5 - frequency);
 * 
 * @param --- Advanced ---
 * @type select
 * @desc Advanced internal configuration options.
 * 
 * @param Property: Move Wait
 * @parent --- Advanced ---
 * @type string
 * @desc Name of the property used to track wait time between moves.
 * Default: _moveWait
 * @default _moveWait
 */
//#endregion

(function() {
'use strict';

    const NAMESPACE   = 'InstantMove';
    const PLUGIN_NAME = 'Cae_' + NAMESPACE;
    const ERR_PRE     = PLUGIN_NAME + '.js ';
    const ERR_NOPARAM = ERR_PRE + 'could not find its parameters!\nCheck the plugin file is named correctly and try again.';
    const ERR_USERFCT = ERR_PRE + 'error in user %1 function: %2';

    window.CAE = window.CAE || {};      // Author namespace

    (($, U) => {

        Object.defineProperty($, 'VERSION', { value: 1.1 });    // Version declaration
        window.Imported = window.Imported || {};                // Import namespace
        Imported[PLUGIN_NAME] = $.VERSION;                      // Import declaration

    // ======== Utility (share) ======== //
    // ======== Parameter stuff ======== //

        void (p => {

            if (!p) { SceneManager.showDevTools(); throw new Error(ERR_NOPARAM); };

            $.switch = parseInt(p['Enable Switch'], 10) || 0;

            /**
             * Formats given function body nicely and wraps it in a try-catch.
             * @param {String} src - Main function text
             * @param {String} errRef - Used for the error message if something goes wrong
             * @returns {String} Function body text wrapped in a try-catch.
             */
            $.mkFctBody = function(src, errRef) {
                let res = 'try {\n\t' + src.replace(/\n/g, '\n\t');
                res += '\n} catch (ex) {\n\tconsole.error("' + ERR_USERFCT;
                return res + '".format("' + errRef + ' wait", ex));\n}';
            };

            /**
             * @param {String} src - Input function body text
             * @param {String} arg - Name of the argument to pass to this function
             * @returns {Function} Function
             */
            $.mkFunc = function(src, arg) { return new Function(arg, $.mkFctBody(src, arg)); };

            $.wait = {
                /**
                 * @param {Number} speed - Movement speed
                 * @returns {Number} Corresponding "move cooldown" time, in frames.
                 */
                speed: $.mkFunc(p['JS: Speed Wait'] || '', 'speed'),
                /**
                 * @param {Number} frequency - Move frequency
                 * @returns {Number} Corresponding "move cooldown" time, in frames.
                 */
                freq:  $.mkFunc(p['JS: Frequency Wait'] || '', 'frequency')
            };
            Object.defineProperty($, 'P_LERPWAIT', { value: String(p['Property: Move Wait']).trim() || '_moveWait' });

        })($.params = PluginManager.parameters(PLUGIN_NAME));

    // ========= Init Routines ========= //
    // ======== Utility (local) ======== //

        /** @returns {Boolean} True iff this plugin's features are enabled. */
        $.isEnabled = function()            { return !$.switch || $gameSwitches.value($.switch); };

        /**
         * @param {Game_CharacterBase} char - Reference character instance
         * @returns {Boolean} True iff the character is on "move cooldown".
         */
        $.isWaiting  = function(char)       { return +char[$.P_LERPWAIT] > 0; };

        /**
         * Updates a given character's "move cooldown" timer by 1 frame.
         * @param {Game_CharacterBase} char - Reference character instance
         */
        $.updateWait = function(char)       { return +char[$.P_LERPWAIT]--; };

        /**
         * Sets a given character's "move cooldown" to a given value.
         * @param {Game_CharacterBase} char - Reference character instance
         * @param {Number} wait - Wait time in frames
         */
        $.setWait    = function(char, wait) { char[$.P_LERPWAIT] = wait; };

        /**
         * @param {Number} v - Speed
         * @param {Number} f - Frequency
         * @returns {Number} Frames to wait before moving again.
         */
        $.calcFrameWait = function(v = 4, f = 5) {
            const speed = Math.max($.wait.speed(v), 0);
            const freq = Math.max($.wait.freq(f), 0);
            return Math.max(speed + freq, 1);
        };

    // ======== Plugin Commands ======== //
    // ============ Extends ============ //
    // ========== Alterations ========== //

        $.alias = $.alias || {};        // This plugin's alias namespace

        // Alias! Ensure tile transitions take only 1 frame.
        void (alias => {
            Game_CharacterBase.prototype.distancePerFrame = function() {
                return $.isEnabled() ? Infinity : alias.apply(this, arguments);
            };
        })(Game_CharacterBase.prototype.distancePerFrame);

        // Alias! Also update wait counter.
        void (alias => {
            Game_CharacterBase.prototype.updateMove = function() {
                alias.apply(this, arguments);
                if ($.isEnabled()) $.updateWait(this);
            };
        })($.alias.Game_CharacterBase_updateMove = Game_CharacterBase.prototype.updateMove);

        // Alias! Prevent gratuitous zoomies.
        void (alias => {
            Game_CharacterBase.prototype.isMoving = function() {
                const res = alias.apply(this, arguments);
                if (!$.isEnabled()) return res;
                if (res) $.setWait(this, $.calcFrameWait(this.realMoveSpeed(), this.moveFrequency()));
                return $.isWaiting(this);
            };
        })($.alias.Game_CharacterBase_isMoving = Game_CharacterBase.prototype.isMoving);

    })(CAE[NAMESPACE] = CAE[NAMESPACE] || {}, CAE.Utils = CAE.Utils || {});

})();