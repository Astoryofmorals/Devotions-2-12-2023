// ==================================================
// Cae_WindowMotion.js
// ==================================================

/**
 * @file Cae_WindowMotion.js (RMMZ)
 * Define custom game window movements.
 * @author Caethyril
 * @version 1.3
 */

//#region Plugin Header
/*:
 * @target MZ
 * @plugindesc v1.3 - Define custom game window movements.
 * @author Caethyril
 * @url https://forums.rpgmakerweb.com/index.php?threads/125657/
 * @orderAfter Cae_MenuDisplayOpts
 * 
 * @help Features:
 *   Specify passive/automatic movement formulae for any game window.
 *   Movement formulae are JavaScript processed in the window's context.
 *   Local variable f: frames since window initialisation.
 *   Formulae should include a return statement!
 *   The value returned (px) will be added to the default position.
 * 
 *   You can also move windows mid-game via plugin commands or on open/close.
 *   Local variable t = 0 to 1: percentage of movement time elapsed.
 *   You can define open/close animation curves in a similar way.
 * 
 *   All formulae are evaluated in the context of the moving window.
 * 
 * Example formulae (passive movement):
 *   Sine wave:
 *     return 20 * Math.sin(Math.PI * f/120);
 *   Back and forth (linear):
 *     return (f%120 >= 60 ? 120-f%120 : f%60) / 2;
 *   Ease in (quadratic, from top):
 *     return -500 / (f/90)**2;
 *   Ease in (exponential, from bottom):
 *     return 5 * Math.pow(1.08, 80 - f/0.9);
 * 
 * Example formulae (active movement):
 *   Linear:
 *     return t;
 *   Quadratic:
 *     return t**2;
 *   Quarter-cosine:
 *     return 1 - (1 + Math.cos(t * Math.PI)) / 2;
 *   Delayed linear:
 *     return t < 0.5 ? 0 : 2 * (t - 0.5);
 * 
 * Plugin Commands:
 *   Move To - move a specific window that is on the current scene;
 *           - destination can be relative to current position;
 *           - can specify transition time and transit/easing curve.
 *             - curve is a function from [0,1]->[0,1]
 *           - persistent offset is stored when the transition completes.
 *   Reset   - move a moved window back to its original position;
 *           - can specify transition time and transit curve, as above.
 *
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
 * Terms of use:
 *   This plugin is free to use and/or modify, under these conditions:
 *     - None of the original plugin header is removed.
 *     - Credit is given to Caethyril for the original work.
 * 
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
 * Compatibility:
 *   Aliases as appropriate for specified windows:
 *      initialize, updatePlacement, update, updateOpen, updateClose,
 *      open, close, show.
 *   Also adds a new property to these windows (configure via parameter).
 *   This plugin does not add data to save files.
 * 
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
 * Changelog:
 *   v1.3 (2020-12-14): Plugin internals completely redesigned!
 *                      Added - Open/Close movement & animation parameters.
 *                      Added - "Reset On Open/Show" parameter.
 *                      Added - "Suspend While Hidden" parameter.
 *                      Added - "Round Positions" parameter to avoid blurring.
 *   v1.2 (2020-08-30): Fixed - careless error in parameter parsing! v_v
 *   v1.1 (2020-08-22): Can now specify active transition duration as an eval.
 *   v1.0 (2020-08-21): Initial release! Rewrite of RMMV version.
 * 
 * @command Move To
 * @desc Adjust the base position of a given window during play.
 * 
 * @arg Reference
 * @type combo
 * @option _messageWindow
 * @option _commandWindow
 * @option _scrollTextWindow
 * @option _goldWindow
 * @option _nameBoxWindow
 * @option _choiceListWindow
 * @option _numberInputWindow
 * @option _eventItemWindow
 * @option _mapNameWindow
 * @option _logWindow
 * @option _statusWindow
 * @option _partyCommandWindow
 * @option _actorCommandWindow
 * @option _helpWindow
 * @option _skillWindow
 * @option _itemWindow
 * @option _actorWindow
 * @option _enemyWindow
 * @desc The window instance to move. Interpreted as a member of the current scene.
 * @default _messageWindow
 * 
 * @arg Axis
 * @type combo
 * @option X
 * @option Y
 * @desc The coordinate to adjust.
 * @default X
 * 
 * @arg JS: Target
 * @type string
 * @desc JavaScript eval: the new value for this coordinate.
 * Evaluated in the context of the reference window.
 * @default 0
 * 
 * @arg Operator
 * @type combo
 * @option Set
 * @option Add
 * @option Sub
 * @option Mul
 * @option Div
 * @option Mod
 * @desc How to apply the new value relative to the current one.
 * @default Set
 * 
 * @arg JS: Frames
 * @type string
 * @desc JavaScript eval: the duration of the transition, in frames. Minimum 1.
 * @default 1
 * 
 * @arg JS: Transit Curve
 * @type multiline_string
 * @desc JavaScript function body: return position (0 = start, 1 = end).
 * 1 argument: t = fraction of transit time elapsed, from 0 to 1.
 * @default return t;  // linear
 * 
 * @command Reset
 * @desc Moves a given window back to its original position.
 * 
 * @arg Reference
 * @type combo
 * @option _messageWindow
 * @option _commandWindow
 * @option _scrollTextWindow
 * @option _goldWindow
 * @option _nameBoxWindow
 * @option _choiceListWindow
 * @option _numberInputWindow
 * @option _eventItemWindow
 * @option _mapNameWindow
 * @option _logWindow
 * @option _statusWindow
 * @option _partyCommandWindow
 * @option _actorCommandWindow
 * @option _helpWindow
 * @option _skillWindow
 * @option _itemWindow
 * @option _actorWindow
 * @option _enemyWindow
 * @desc The window instance to move.
 * (Relative to current scene.)
 * @default _messageWindow
 * 
 * @arg Axis
 * @type combo
 * @option All
 * @option X
 * @option Y
 * @desc The coordinate to adjust.
 * @default All
 * 
 * @arg JS: Frames
 * @type string
 * @desc JavaScript eval: the duration of the transition, in frames. Minimum 1.
 * @default 1
 * 
 * @arg JS: Transit Curve
 * @type multiline_string
 * @desc Function body: return position (0 = start, 1 = end).
 * 1 argument: t = fraction of transit time elapsed, from 0 to 1.
 * @default return t;  // linear
 * 
 * @param Passive Movement
 * @type struct<WindowMoveFormula>[]
 * @desc List of applicable windows and their passive/automatic movement formulae.
 * @default []
 * 
 * @param Round Positions
 * @type boolean
 * @desc If true, window coordinates will be rounded to the nearest pixel.
 * @default true
 *
 * @param --- Advanced ---
 * @type select 
 * @desc Advanced internal configuration options.
 *
 * @param Property: Plugin Data
 * @parent --- Advanced ---
 * @type string
 * @desc The property name added to game windows under which this plugin stores relevant data.
 * @default Cae_WindowMotion
 */
//========================================
/*~struct~WindowMoveFormula:
 * @param Constructor
 * @type combo
 * @option Window_Base
 * @option Window_GameEnd
 * @option Window_MapName
 * @option Window_Message
 * @option Window_NameEdit
 * @option Window_NameInput
 * @option Window_Options
 * @option Window_ScrollText
 * @option Window_ShopNumber
 * @option Window_TitleCommand
 * @option Window_BattleLog
 * @option Window_PartyCommand
 * @option Window_ActorCommand
 * @option Window_BattleStatus
 * @option Window_BattleActor
 * @option Window_BattleEnemy
 * @option Window_BattleSkill
 * @option Window_BattleItem
 * @desc The window constructor. Case-sensitive!
 * @default Window_Message
 * 
 * @param Reset On Open/Show
 * @type boolean
 * @desc If true, this window's position will reset when it is opened/shown.
 * @default true
 * 
 * @param Suspend While Hidden
 * @type boolean
 * @desc If true, this window will have its movement suspended while it is marked "hidden".
 * @default true
 *
 * @param --- Passive ---
 * @type select
 * @desc Passive movement definitions for this window.
 * 
 * @param JS: Formula X
 * @parent --- Passive ---
 * @type multiline_string
 * @desc Formula for this window's x-position offset.
 * Use f for frame count since the window was opened.
 * @default return 0;
 *
 * @param JS: Formula Y
 * @parent --- Passive ---
 * @type multiline_string
 * @desc Formula for this window's y-position offset.
 * Use f for frame count since the window was opened.
 * @default return 0;
 *
 * @param --- Open ---
 * @type select
 * @desc Optional transition motion applied when the window opens.
 * 
 * @param JS: Open Frames
 * @parent --- Open ---
 * @type string
 * @desc JavaScript eval for the duration (frames) of the open-window movement. 0 = no motion.
 * @default 0
 * 
 * @param JS: Open From X
 * @parent --- Open ---
 * @type string
 * @desc JavaScript eval for the starting X coordinate of the open-window movement.
 * @default 0
 *
 * @param JS: Open From Y
 * @parent --- Open ---
 * @type string
 * @desc JavaScript eval for the starting Y coordinate of the open-window movement.
 * @default 0
 * 
 * @param JS: Open Curve X
 * @parent --- Open ---
 * @type multiline_string
 * @desc JavaScript function body: return position (0 = start, 1 = end).
 * 1 argument: t = fraction of transit time elapsed, from 0 to 1.
 * @default return t;  // linear
 * 
 * @param JS: Open Curve Y
 * @parent --- Open ---
 * @type multiline_string
 * @desc JavaScript function body: return position (0 = start, 1 = end).
 * 1 argument: t = fraction of transit time elapsed, from 0 to 1.
 * @default return t;  // linear
 * 
 * @param JS: Open Anim Frames
 * @parent --- Open ---
 * @type string
 * @desc JavaScript eval for the duration (frames) of the open-window animation. Default: 8.
 * @default
 * 
 * @param JS: Open Anim Curve
 * @parent --- Open ---
 * @type multiline_string
 * @desc JavaScript function body: return openness (0 = shut, 1 = open).
 * 1 argument: t = fraction of opening time elapsed, from 0 to 1.
 * @default return t;  // linear
 * 
 * @param Delay Open Move
 * @parent --- Open ---
 * @type boolean
 * @desc If true, opening movement will wait for opening animation to complete before starting.
 * @default true
 * 
 * @param --- Close ---
 * @type select
 * @desc Transition motion applied when the window closes.
 * 
 * @param JS: Close Frames
 * @parent --- Close ---
 * @type string
 * @desc JavaScript eval for the duration (frames) of the close-window movement. 0 = no motion.
 * @default 0
 * 
 * @param JS: Close To X
 * @parent --- Close ---
 * @type string
 * @desc JavaScript eval for the final X coordinate of the close-window movement.
 * @default 0
 *
 * @param JS: Close To Y
 * @parent --- Close ---
 * @type string
 * @desc JavaScript eval for the final Y coordinate of the close-window movement.
 * @default 0
 * 
 * @param JS: Close Curve X
 * @parent --- Close ---
 * @type multiline_string
 * @desc JavaScript function body: return position (0 = start, 1 = end).
 * 1 argument: t = fraction of transit time elapsed, from 0 to 1.
 * @default return t;  // linear
 * 
 * @param JS: Close Curve Y
 * @parent --- Close ---
 * @type multiline_string
 * @desc JavaScript function body: return position (0 = start, 1 = end).
 * 1 argument: t = fraction of transit time elapsed, from 0 to 1.
 * @default return t;  // linear
 * 
 * @param JS: Close Anim Frames
 * @parent --- Close ---
 * @type string
 * @desc JavaScript eval for the duration (frames) of the close-window animation. Default: 8.
 * @default
 * 
 * @param JS: Close Anim Curve
 * @parent --- Close ---
 * @type multiline_string
 * @desc JavaScript function body: return openness (0 = shut, 1 = open).
 * 1 argument: t = fraction of closing time elapsed, from 0 to 1.
 * @default return 1 - t;  // linear
 * 
 * @param Delay Close Anim
 * @parent --- Close ---
 * @type boolean
 * @desc If true, custom closing animation will wait for closing movement to complete before starting.
 * @default true
 */
//#endregion Plugin Header

(function() {
'use strict';

    const NAMESPACE   = 'WindowMotion';
    const PLUGIN_NAME = 'Cae_' + NAMESPACE;
    const ERR_PRE     = PLUGIN_NAME + '.js ';
    const ERR_NOPARAM = ERR_PRE + 'could not find its parameters!\nCheck the plugin file is named correctly and try again.';
    const ERR_USERFCT = ERR_PRE + 'encountered an error with user function %1#%2.';
    const WARN_NOWIN  = ERR_PRE + 'cannot reference undefined window "%1".';

    window.CAE = window.CAE || {};      // Author namespace
    
    (($, U) => {

        Object.defineProperty($, 'VERSION', { value: 1.3 });    // Version declaration
        window.Imported = window.Imported || {};                // Import namespace
        Imported[PLUGIN_NAME] = $.VERSION;                      // Import declaration

        /** Intial value for frame count of passive window motion. */
        $.INIT_FRAME = 0;

        // Convenient blocks for building functions.
        const FUNCSPACE = 'CAE.' + NAMESPACE;
        const PPLUGDATA = 'this[' + FUNCSPACE + '.P]';

        // Neatness
        const AXES = ['x', 'y'];

        /* -------------------------
         *      Structure notes
         * -------------------------
         * Adds properties to windows:
         *   - PFC   : passive frame count
         *   - PBX|Y : initial X|Y position
         *   - POX|Y : persistent X|Y offset
         *   - OFC|K : current|final open anim frame count
         *   - CFC|K : current|final close anim frame count
         *   - OMD   : if true, open move is being delayed 'til open anim completes
         *   - CAD   : if true, close anim is being delayed 'til close move completes
         * These properties will be deleted when their presence is unnecessary.
         * 
         * Transit data will also be added:
         *   - TD    : transit data object, contains the following for each axis
         *      - xa : start point (x-axis)
         *      - xb : end point (x-axis)
         *      - xt : frame count (x-axis)
         *      - xT : total frames (x-axis)
         *      - xu : transit curve (x-axis)
         *      - xn : transit type, a miscellaneous identifier (x-axis)
         * Transit data will be present only during transit.
         * The parent object may persist after all transits end.
         */

    // ======== Utility (share) ======== //

        void (f => { if (U[f]) return;
            /**
             * @param {Number} a - operand 1 (left)
             * @param {Number} b - operand 2 (right)
             * @param {String} op - operator: SET, ADD, SUB, MUL, DIV, or MOD
             * @returns {Number} Result of a op b.
             */
            U[f] = function(a, b, op) {
                switch (String(op || '').toUpperCase()) {
                    case 'SET': return b;
                    case 'ADD': return a + b;
                    case 'SUB': return a - b;
                    case 'MUL': return a * b;
                    case 'DIV': return a / b;
                    case 'MOD': return a.mod(b);
                    default:    return a;
                }
            };
        })('operate');

        void (f => { if (U[f]) return;
            /**
             * @param {String} text - input text for eval
             * @param {Number} dFault - default value, returned on error or non-numerical eval
             * @param {Number} base - base for parseInt
             * @returns {Number} Eval of text coerced to integer, else given default value.
             */
            U[f] = function(text = '', dFault = 0, base = 10) {
                try {
                    const res = eval(text);
                    if (isNaN(res)) throw new Error('Not a number: ' + res);
                    return parseInt(res, base);
                } catch (ex) {
                    console.error('Eval error:\n' + text + '\n\n' + ex);
                    return dFault;
                }
            };
        })('tryEvalInt');

    // ======== Parameter stuff ======== //

        void (p => {

            if (!p) { SceneManager.showDevTools(); throw new Error(ERR_NOPARAM); };

            $.w = JSON.parse(p['Passive Movement'] || '{}').map(JSON.parse).filter((o, n, a) =>
                n === a.findIndex(f => f.Constructor === o.Constructor));
            $.r = p['Round Positions'] === 'true';

            /** Property added to applicable window instances, under which this plugin stores data. */
            Object.defineProperty($, 'P', { value: p['Property: Plugin Data'] || 'Cae_WindowMotion' });

        })($.params = PluginManager.parameters(PLUGIN_NAME));

    // ======== Utility (local) ======== //

        // Utility functions for confirming the necessary data exists to make a user function.
        $.isCustom = {
            /**
             * @param {Object} o - Plugin config data for relevant window
             * @returns {Boolean} True iff should define a custom openAnim alias for this window.
             */
            openAnim:  function(o) { return !!o.oaf; },
            /**
             * @param {Object} o - Plugin config data for relevant window
             * @returns {Boolean} True iff should define a custom closeAnim alias for this window.
             */
            closeAnim: function(o) { return !!o.caf; }
        };

        // User-function builder methods
        $.mkFct = {
            /**
             * 
             * @param {String} body - Function body text
             * @param {String} c - Window constructor name, used for error message
             * @param {String} f - Function name, used for error message
             * @param {String[]} args - Array of argument names
             * @returns {Function} Function created from inputs
             */
            core: function(body, f, c) {
                return new Function(this.wrapTry(body, f, c));
            },
            /**
             * @param {String} body - Function body text
             * @param {String} f - Function name, used for error message
             * @param {String} c - Window constructor name, used for error message
             * @returns {String} Function body wrapped in a try-catch
             */
            wrapTry: function(body, f = 'unknown', c = '*') {
                return 'try {\n\t' + body.replace(/\n/g, '\n\t') +
                    '\n} catch (ex) {\n\tSceneManager.showDevTools();\n\tconsole.error("' +
                    ERR_USERFCT.format(c, f) + '");\n\tthrow ex;\n}';
            },
            /**
             * @param {String} body - Function body text
             * @returns {String} Input formatted as an IIFE
             */
            iife: function(body) {
                return '(() => {\n\t' + body.replace(/\n/g, '\n\t') + '\n})()';
            },
            /**
             * @param {Object} o - Plugin config data for relevant window
             * @returns {Function} Passive movement function () => {x, y}
             */
            passive: function(o) {
                const res = 'const f = ' + PPLUGDATA + '.PFC;\n' +
                    'return { x: ' + (o.x ? 'Number(' + this.iife(o.x) + ') || 0' : '0') +
                           ', y: ' + (o.y ? 'Number(' + this.iife(o.y) + ') || 0' : '0') + ' };';
                return this.core(res, 'passive', o.n);
            },
            /**
             * @param {Object} o - Plugin config data for relevant window
             * @returns {Function} Opening animation function () => openness
             */
            openAnim: function(o) {
                if (!$.isCustom.openAnim(o)) return;
                const res = 'const t = ' + PPLUGDATA + '.OFC / ' + PPLUGDATA + '.OFK;\n' +
                    'return 255 * ' + (o.oau ? '(Number(' + this.iife(o.oau) + ') || 1)' : 't') + ';\n';
                return this.core(res, 'openAnim', o.n);
            },
            /**
             * @param {Object} o - Plugin config data for relevant window
             * @returns {Function} Closing animation function () => openness
             */
            closeAnim: function(o) {
                if (!$.isCustom.closeAnim(o)) return;
                const res = 'const t = ' + PPLUGDATA + '.CFC / ' + PPLUGDATA + '.CFK;\n' +
                    'return 255 * ' + (o.cau ? '(Number(' + this.iife(o.cau) + ') || 0)' : '(1 - t)') + ';\n';
                return this.core(res, 'closeAnim', o.n);
            },
            /**
             * @param {String} axis - Lowercase axis of transit: "x" or "y"
             * @param {String} body - Function body text
             * @returns {Function} Transit function () => x|y
             */
            transit: function(axis, body) {
                const D = PPLUGDATA + '.TD.' + axis + '%1';
                const res = 'const T = ' + D.format('T') + ';\n' + 'const t = ' + D.format('t') + ' / T;\n' +
                    'return Number(' + (body ? this.iife(body) : 't') + ')' +
                    ' * ((' + D.format('b') + ') - (' + D.format('a') + '));';
                return this.core(res, 'transit');
            }
        };

        /**
         * @param {?} n - Input value, e.g. from user function
         * @returns {Number} Numerical value or 0 if input was non-numerical.
         */
        $.validateNum = function(n) { return (n && !isNaN(n)) ? Number(n) : 0; };

        /**
         * Resets given instance's persistent positional offsets and passive frame count.
         * @param {Window_Base} w - Reference window instance
         */
        $.resetPos = function(w) {
            const o = w[$.P] = w[$.P] || {};
            o.PFC = $.INIT_FRAME;   // passive frame count
            o.POX = 0;              // persistent offset x (from transitions)
            o.POY = 0;              // persistent offset y
            w.x = o.PBX;
            w.y = o.PBY;
        };

        /**
         * Initialises given instance's location.
         * @param {Window_Base} w - Reference window instance
         */
        $.initPos = function(w) {
            const o = w[$.P] = w[$.P] || {};
            o.PBX = w.x;            // passive base x (starting pos)
            o.PBY = w.y;            // passive base y
            $.resetPos(w);
        };

        /**
         * Used for combining contributions to a window's positional offset.
         * @param {...Number} args - Values to combine
         * @returns {Number} Combined value
         */
        $.combinePos = function(...args) {
            const sum = args.reduce((a, c) => a + $.validateNum(c), 0);
            return $.r ? Math.round(sum) : sum;
        };

        // Referenced when clearing transit data.
        $.transitKeys = ['a','b','n','t','T','u'];

        // Methods for clearing unwanted properties
        $.clear = {
            /**
             * Removes this plugin's "open window" related properties from given instance.
             * @param {Window_Base} w - Reference window instance
             */
            open: function(w) {
                const D = w?.[$.P];
                if (D) delete D.OFC, delete D.OFK, delete D.OMD;
            },
            /**
             * Removes this plugin's "close window" related properties from given instance.
             * @param {Window_Base} w - Reference window instance
             */
            close: function(w) {
                const D = w?.[$.P];
                if (D) delete D.CFC, delete D.CFK, delete D.CAD;
            },
            /**
             * Removes this plugin's transit properties for specified axis from given instance.
             * @param {Window_Base} w - Reference window instance
             * @param {String} a - Lowercase axis: x or y
             */
            transit: function(w, a) {
                const D = w?.[$.P]?.TD;
                if (D) $.transitKeys.forEach(k => delete D[a + k]);
            }
        };

        /**
         * Starts a new active movement along one axis.
         * @param {Window_Base} w - Reference window instance
         * @param {String} a - Lowercase axis: x or y
         * @param {Number} f - Full duration (frames) of transit
         * @param {Number} v - Target point
         * @param {String} p - Operator: SET, ADD, SUB, MUL, DIV, or MOD
         * @param {String} u - Transit curve function body text
         * @param {String} n - Transit type identifier
         */
        $.applyTransit = function(w, a, f, v, p = 'SET', u = 'return t;', n = '') {
            if (!w || !a || !f) return;
            const D = w[$.P];
            const o = D.TD = D.TD || {};
            $.cutTransit(w, a);
            o[a + 'a'] = w[a];
            o[a + 'b'] = U.operate(o[a + 'a'], v, p);
            o[a + 'T'] = f;
            o[a + 't'] = 0;
            o[a + 'u'] = $.mkFct.transit(a, u);
            if (n) o[a + 'n'] = a + '-' + n;
        };

        /**
         * Cuts short a transit in progress
         * @param {Window_Base} w - Reference window instance
         * @param {String} a - Lowercase axis: x or y
         * @returns {Boolean} True iff a transit was cut.
         */
        $.cutTransit = function(w, a) {
            const D = w[$.P];
            if (D.TD[a + 't']) {
                D['PO' + a.toUpperCase()] += w[a] - D.TD[a + 'a'];
                $.clear.transit(w, a);
                return true;
            }
            return false;
        };

        /**
         * Ends a transit in progress [of the stated type].
         * @param {Window_Base} w - Reference window instance
         * @param {String} a - Lowercase axis: x or y
         * @param {String} n - Transit type to affect
         * @returns {Boolean} True iff a transit was terminated.
         */
        $.endTransit = function(w, a, n = '') {
            const o = w[$.P]?.TD;
            if (o?.[a + 't']) {
                if (n && (!o?.[a + 'n'] || '').slice(2) === n) return false;
                $.onComplete.transit(w, o[a + 'n']);
                $.cutTransit(w, a);
                return true;
            }
            return false;
        };

        /**
         * Ends all transits in progress [of the stated type].
         * @param {Window_Base} w - Reference window instance
         * @param {String} n - Transit type to affect
         * @returns {Boolean} True iff at least one transit was terminated.
         */
        $.endAllTransits = function(w, n = '') {
            return AXES.reduce((a, c) => $.endTransit(w, c, n) || a, false);
        };

        /**
         * Applies opening movement for given window instance.
         * @param {Window_Base} w - Reference window instance
         * @param {Object} o - Plugin config data for relevant window
         */
        $.applyOpenTransit = function(w, o) {
            const transitType = 'open';
            $.endAllTransits(w, 'close');
            if (o.of && !w.isOpen()) {
                const D = w[$.P];
                const f = U.tryEvalInt.call(w, o.of);       // w o o f
                if (o.ox && o.oux) {
                    const v = w.x, x = U.tryEvalInt.call(w, o.ox);
                    w.x = x;
                    D.POX += x - v;
                    $.applyTransit(w, 'x', f, v, 'SET', o.oux, transitType);
                }
                if (o.oy && o.ouy) {
                    const v = w.y, y = U.tryEvalInt.call(w, o.oy);
                    w.y = y;
                    D.POY += y - v;
                    $.applyTransit(w, 'y', f, v, 'SET', o.ouy, transitType);
                }
            }
        };

        /**
         * Applies closing movement for given window instance.
         * @param {Window_Base} w - Reference window instance
         * @param {Object} o - Plugin config data for relevant window
         */
        $.applyCloseTransit = function(w, o) {
            const transitType = 'close';
            $.endAllTransits(w, 'open');
            if (o.cf && !w.isClosed()) {
                const f = U.tryEvalInt.call(w, o.cf);
                if (o.cx && o.cux) {
                    const v = U.tryEvalInt.call(w, o.cx);
                    $.applyTransit(w, 'x', f, v, 'SET', o.cux, transitType);
                }
                if (o.cy && o.cuy) {
                    const v = U.tryEvalInt.call(w, o.cy)
                    $.applyTransit(w, 'y', f, v, 'SET', o.cuy, transitType);
                }
            }
        };

        /**
         * @param {Window_Base} w - Reference window instance
         * @returns {{tx:Number,ty:Number}} Transit offset coordinates
         */
        $.updateTransit = function(w) {
            const D = w[$.P];
            const res = { x: 0, y: 0 };
            if (D.TD) {
                AXES.forEach(a => {
                    if (D.TD[a + 't'] !== undefined) {                                  // exists
                        if (D.TD[a + 't'] >= D.TD[a + 'T']) {                           // complete
                            D['PO' + a.toUpperCase()] += D.TD[a + 'b'] - D.TD[a + 'a'];
                            $.onComplete.transit(w, D.TD[a + 'n']);
                            $.clear.transit(w, a);
                        } else {                                                        // in progress
                            D.TD[a + 't']++;
                            res[a] = D.TD[a + 'u'].call(w);
                        }
                    }
                });
            }
            return res;
        };

        // Additional hooks for ease of modding
        $.onComplete = {
            /**
             * Called when given window's transition completes, before erasing transit data.
             * @param {Window_Base} w - Reference window instance
             */
            transit:   function(w) { /* nothing */ },
            /**
             * Called when given window's custom open animation completes.
             * @param {Window_Base} w - Reference window instance
             */
            openAnim:  function(w) { /* nothing */ },
            /**
             * Called when given window's custom close animation completes.
             * @param {Window_Base} w - Reference window instance
             */
            closeAnim: function(w) { /* nothing */ }
        };

        /**
         * Calculates current position based on passive and active movements.
         * @param {Window_Base} w - Reference window instance
         * @param {String} c - Constructor name, for function lookup
         * @returns {{x:Number,y:Number}} Resultant position.
         */
        $.calcPos = function(w, c) {
            let {x: px, y: py} = $.f[c].passive.call(w);     // passive offset
            let {x: tx, y: ty} = $.updateTransit(w);         // active transits
            const D = w[$.P];
            return {
                x: $.combinePos(D.PBX, D.POX, px, tx),
                y: $.combinePos(D.PBY, D.POY, py, ty)
            };
        };

        // Alias builder methods
        $.mkAlias = {
            /**
             * @param {Function} alias - Reference to original method
             * @param {Object} o - Plugin config data for relevant window
             * @returns {Function} New initialize method.
             */
            initialize: function(alias, o) {
                return function() {
                    alias.apply(this, arguments);
                    $.initPos(this);
                };
            },
            /**
             * Some windows adjust their position after initialisation.
             * @param {Function} alias - Reference to original method
             * @param {Object} o - Plugin config data for relevant window
             * @returns {Function} New updatePlacement method
             */
            updatePlacement: function(alias, o) {
                return this.initialize(...arguments);
            },
            /**
             * @param {Function} alias - Reference to original method
             * @param {Object} o - Plugin config data for relevant window
             * @returns {Function} New update method.
             */
            update: function(alias, o) {
                return function() {
                    alias.apply(this, arguments);
                    if (o.s && !this.visible) return;       // suspend while hidden
                    const {x, y} = $.calcPos(this, o.n);
                    this.x = x, this.y = y;
                };
            },
            /**
             * @param {Function} alias - Reference to original method
             * @param {Object} o - Plugin config data for relevant window
             * @returns {Function} New updateOpen method.
             */
            updateOpen: function(alias, o) {    // essentially an override
                const f = $.f[o.n]?.openAnim;
                if (f) {
                    return function() {
                        alias.apply(this, arguments);       // for optimal compatibility
                        const D = this[$.P];
                        if (D.OFC !== undefined) {
                            this._opening = D.OFC < D.OFK;
                            if (this._opening) {
                                D.OFC++;
                                this.openness = f.call(this);
                            } else {
                                this.openness = 255;
                                $.clear.open(this);
                                if (o.od) $.applyOpenTransit(this, o);
                                $.onComplete.openAnim(this);
                            }
                        }
                    };
                } else {
                    return function() {     // opening move waits for default open anim
                        alias.apply(this, arguments);
                        const D = this[$.P];
                        if (D.OMD && this.isOpen()) {
                            $.applyOpenTransit(this, o);
                            delete D.OMD;
                        }
                    };
                }
            },
            /**
             * @param {Function} alias - Reference to original method
             * @param {Object} o - Plugin config data for relevant window
             * @returns {Function} New updateClose method.
             */
            updateClose: function(alias, o) {
                const f = $.f[o.n]?.closeAnim;
                if (f) {
                    return function() {
                        alias.apply(this, arguments);       // optimal compatibility
                        const D = this[$.P];
                        if (D.CFC !== undefined) {
                            this._closing = D.CFC < D.CFK;
                            if (this._closing) {
                                D.CFC++;
                                this.openness = f.call(this);
                            } else {
                                this.openness = 0;
                                $.clear.close(this);
                                $.onComplete.closeAnim(this);
                            }
                        }
                    };
                } else {
                    return function() {     // default close anim waits for closing move
                        const D = this[$.P];
                        if (!D.CAD || !D.CFK) {
                            alias.apply(this, arguments);
                            delete D.CAD;
                        }
                    };
                }
            },
            /**
             * @param {Function} alias - Reference to original method
             * @param {Object} o - Plugin config data for relevant window
             * @returns {Function} New open method.
             */
            open: function(alias, o) {
                return function() {
                    alias.apply(this, arguments);
                    if (o.r) $.resetPos(this);
                    const D = this[$.P];
                    if (!this.isOpen() && $.f[o.n]?.openAnim) {
                        D.OFC = 0;
                        D.OFK = U.tryEvalInt.call(this, o.oaf);
                    }
                    $.clear.close(this);
                    if (o.od) D.OMD = true;
                    else $.applyOpenTransit(this, o);
                };
            },
            /**
             * @param {Function} alias - Reference to original method
             * @param {Object} o - Plugin config data for relevant window
             * @returns {Function} New close method.
             */
            close: function(alias, o) {
                return function() {
                    alias.apply(this, arguments);
                    const D = this[$.P];
                    if (!this.isClosed() && $.f[o.n]?.closeAnim) {
                        D.CFC = o.cd ? -U.tryEvalInt.call(this, o.cf) : 0;
                        D.CFK = U.tryEvalInt.call(this, o.caf);
                    }
                    $.clear.open(this);
                    if (o.cd) D.CAD = true;
                    $.applyCloseTransit(this, o);
                };
            },
            /**
             * @param {Function} alias - Reference to original method
             * @param {Object} o - Plugin config data for relevant window
             * @returns {Function} New show method.
             */
            show: function(alias, o) {
                if (!o.r) return;
                return function() { $.resetPos(this); alias.apply(this, arguments); };
            }
        };

        /** Array of method names for aliasing. */
        Object.defineProperty($, 'aliasKeys', { get: () => Object.keys($.mkAlias), configurable: true });

        /**
         * @param {String} c - Constructor name
         * @param {String} m - Method name
         * @returns {String} Name under which this alias should be stored.
         */
        $.aliasName = function(c, m) { return c + '_' + m; };

        /**
         * Applies all applicable aliases for given window record.
         * @param {Object} o - Plugin config data for relevant window
         */
        $.mkAliases = function(o) {
            const c = o.n;
            const w = window[c]?.prototype;
            if (w) {
                $.aliasKeys.forEach(k => {
                    if (w[k]) {
                        const A = $.aliasName(c, k);
                        const a = $.mkAlias[k]($.alias[A] = w[k], o);
                        if (a) w[k] = a;
                        else delete $.alias[A];
                    }
                });
            } else console.warn(WARN_NOWIN.format(c));
        };

        /**
         * @param {String} c - Constructor name
         * @param {String} m - Method name
         * @returns {Boolean} True iff this plugin has an alias [for specified method] under this constructor name.
         */
        $.hasAlias = function(c, m = 'initialize') { return !!$.alias[$.aliasName(c, m)]; };

        /**
         * Used for invoking active moves on windows without a passive movement record.
         * @param {String} c - Constructor name
         * @returns {Object} Blank plugin parameter record
         */
        $.mkBlank = function(c) {
            const I = $._init;
            const r = I.record({ 'Constructor': c });
            $.w.push(r);
            I.fct(r);
            return r;
        };

    // ========= Init Routines ========= //

        // Plugin data initialisation methods
        $._init = {
            /**
             * Initialises some functions for a single window.
             * @param {Object} o - Plugin config data for relevant window
             */
            fct: function(o) {
                $.f = $.f || {};
                $.f[o.n] = {
                    passive:   $.mkFct.passive(o),
                    openAnim:  $.mkFct.openAnim(o),
                    closeAnim: $.mkFct.closeAnim(o)
                }
            },
            /** Initialises some functions from plugin parameters. */
            fcts: function() {
                $.w.forEach(o => $._init.fct(o));
            },
            /** Parses plugin parameters. */
            params: function() {
                $.w = $.w.filter(o => o.Constructor).map(o => $._init.record(o));
            },
            /**
             * @param {Object} o - Plugin parameter record
             * @returns {Object} Parsed record
             */
            record: function(o) {
                return {
                    n:   o.Constructor,
                    r:   o['Reset On Open/Show'] === 'true',
                    s:   o['Suspend While Hidden'] === 'true',
                    x:   o['JS: Formula X'],
                    y:   o['JS: Formula Y'],
                    of:  o['JS: Open Frames'],
                    ox:  o['JS: Open From X'],
                    oy:  o['JS: Open From Y'],
                    oux: o['JS: Open Curve X'],
                    ouy: o['JS: Open Curve Y'],
                    oaf: o['JS: Open Anim Frames'],
                    oau: o['JS: Open Anim Curve'],
                    od:  o['Delay Open Move'] === 'true',
                    cf:  o['JS: Close Frames'],
                    cx:  o['JS: Close To X'],
                    cy:  o['JS: Close To Y'],
                    cux: o['JS: Close Curve X'],
                    cuy: o['JS: Close Curve Y'],
                    caf: o['JS: Close Anim Frames'],
                    cau: o['JS: Close Anim Curve'],
                    cd:  o['Delay Close Anim'] === 'true'
                };
            }
        };

        /** Initialises this plugin's data. */
        $.initAll = function() {
            const I = $._init;
            I.params();
            I.fcts();
        };
        $.initAll();

    // ======== Plugin Commands ======== //

        $.com = {
            /**
             * @param {Object} args - Plugin command arguments
             * @returns {{w:Window_Base,a:String,c:String}} Validated arguments (else blank string):
             * - w: Window object instance from property name
             * - a: Axis in lowercase: "x" or "y"
             * - c: Constructor name
             */
            validate: function(args) {
                const r = args.Reference;
                if (!r) return;
                const w = SceneManager._scene[r];
                if (!w) return;
                const c = w.constructor.name;
                if (!c) return;
                const a = String(args.Axis || '').toLowerCase();
                if (!a) return;
                return { w: w, a: a, c: c };
            },
            /**
             * Starts an active movement for the specified window instance.
             * - Target is specified eval.
             * @param {{"Reference":String,"Axis":String,"JS: Target":String,"Operator":String,"JS: Frames":String,"JS: Transit Curve":String}} args - Plugin command arguments
             */
            moveTo: function(args) {
                const {w, a, c} = $.com.validate(args);
                if (!w) return;
                if (!$.hasAlias(c)) {
                    $.mkAliases($.mkBlank(c));
                    $.initPos(w);
                }
                const v = U.tryEvalInt.call(w, args['JS: Target'])
                const p = args['Operator'];
                const f = Math.max(U.tryEvalInt.call(w, args['JS: Frames']), 1);
                const u = args['JS: Transit Curve'];
                return $.applyTransit(w, a, f, v, p, u, 'cmd:moveTo');
            },
            /**
             * Starts an active movement for the specified window instance.
             * - Target is the window's base position.
             * @param {{"Reference":String,"Axis":String,"JS: Frames":String,"JS: Transit Curve":String}} args - Plugin command arguments
             */
            resetPos: function(args) {
                const {w, a, c} = $.com.validate(args);
                if (!w) return;
                if (!$.hasAlias(c)) return;   // window was not moved by this plugin
                if (a === 'all') return AXES.forEach(e => {
                    const args2 = JsonEx.makeDeepCopy(args);     // eh
                    args2.Axis = e;
                    $.com.resetPos(args2);
                });
                const v = w[$.P]['PB' + a.toUpperCase()];
                const p = 'SET';
                const f = Math.max(U.tryEvalInt.call(w, args['JS: Frames']), 1);
                const u = args['JS: Transit Curve'];
                return $.applyTransit(w, a, f, v, p, u, 'cmd:resetPos');
            }
        };
        PluginManager.registerCommand(PLUGIN_NAME, 'Move To', $.com.moveTo);
        PluginManager.registerCommand(PLUGIN_NAME, 'Reset', $.com.resetPos);

    // ============ Extends ============ //
    // ========== Alterations ========== //

        $.alias = $.alias || {};        // This plugin's alias namespace

        $.w.forEach(o => $.mkAliases(o));   // Make relevant aliases re plugin parameters

    })(CAE[NAMESPACE] = CAE[NAMESPACE] || {}, CAE.Utils = CAE.Utils || {});

})();