// ==================================================
// Cae_TileAnimExt.js
// ==================================================

/**
 * @file Cae_TileAnimExt.js (RMMZ)
 * Adjust animated tile frame rate and sequence.
 * @author Caethyril
 * @version 1.3
 */

//#region Plugin header
/*:
 * @target MZ
 * @plugindesc v1.3 - Adjust animated tile frame rate and sequence.
 * @author Caethyril
 * @url https://forums.rpgmakerweb.com/index.php?threads/caethyrils-mz-plugins.125657/
 * 
 * @help Features:
 *   Adjust the tile animation rate (default 2 fps).
 *   Adjust the tile animation sequences: normal water and waterfalls.
 *   Optionally add an on/off animation setting to the options menu.
 * 
 * Plugin Command:
 *   Set Rate                 - set tile animation rate
 *   Reset Rate               - reset tile animation rate to starting value
 *   Set Animation Sequence   - set tile animation frame sequence
 *   Reset Animation Sequence - reset tile animation sequence to starting value
 *
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
 * Terms of use:
 *   This plugin is free to use and/or modify, under these conditions:
 *     - None of the original plugin header is removed.
 *     - Credit is given to Caethyril for the original work.
 * 
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
 * Compatibility:
 *   Overrides: Tilemap:
 *                _addAutotile
 *   Aliases:   Tilemap:
 *                update
 *              Scene_Options:
 *                maxCommands
 *              ConfigManager:
 *                makeData, applyData
 *              DataManager:
 *                createGameObjects, makeSaveContents, extractSaveContents
 *   Defines:   ConfigManager:
 *                tileAnimRate (name configurable via parameters)
 *   This plugin adds data to the settings file, and optionally to save files.
 * 
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
 * Changelog:
 *   v1.3 (2022-06-02): v1.5.0 tile size compatibility update.
 *   v1.2 (2020-09-07): Fixed - plugin should always initialise on new game.
 *                      Fixed - options window should now scale correctly.
 *   v1.1 (2020-08-22): Fixed - plugin data should now save/load correctly.
 *   v1.0 (2020-08-20): Initial release! Rewrite of RMMV version.
 * 
 * @command Set Rate
 * @desc Set the tile animation rate mid-game.
 * 
 * @arg Rate
 * @type number
 * @min 0
 * @max 60
 * @desc Tile animation rate in frames per second.
 * Default: 2
 * @default 2
 * 
 * @command Reset Rate
 * @desc Reset the tile animation rate to the value defined in this plugin's parameters.
 * 
 * @command Set Animation Sequence
 * @desc Set a tile animation sequence mid-game.
 * 
 * @arg Type
 * @type combo
 * @option Normal
 * @option Waterfall
 * @desc The type of animation sequence to set.
 * @default Normal
 * 
 * @arg Sequence
 * @type number[]
 * @min 0
 * @max 2
 * @desc Order of frames for this tile animation sequence.
 * @default
 * 
 * @command Reset Animation Sequence
 * @desc Reset a tile animation sequence to the value defined in this plugin's parameters.
 * 
 * @arg Type
 * @type combo
 * @option Normal
 * @option Waterfall
 * @desc The type of animation sequence to reset.
 * @default Normal
 * 
 * @param Tile Animation Rate
 * @type number
 * @min 0
 * @max 60
 * @desc Tile animation rate in frames per second.
 * Default: 2
 * @default 2
 *
 * @param Tile Anim Sequence
 * @text Tile Anim Sequence
 * @type number[]
 * @min 0
 * @max 2
 * @desc Order of frames for standard tile animation.
 * Default: [0, 1, 2, 1]
 * @default ["0","1","2","1"]
 *
 * @param Waterfall Anim Sequence
 * @text Waterfall Anim Sequence
 * @type number[]
 * @min 0
 * @max 2
 * @desc Order of frames for waterfall tile animation.
 * Default: [0, 1, 2]
 * @default ["0","1","2"]
 * 
 * @param Tile Animation Option
 * @type string
 * @desc Text shown for the on/off animation option in-game.
 * Leave blank to hide the option.
 * @default
 * 
 * @param Add Save Data
 * @type boolean
 * @desc If true, current rate and animation sequences will be added to save files. Unnecessary if not using the plugin commands.
 * @default false
 * 
 * @param --- Advanced ---
 * @type select
 * @desc Advanced internal configuration options.
 * 
 * @param Config Key
 * @parent --- Advanced ---
 * @type string
 * @desc Property key for ConfigManager on/off tile animation setting.
 * Default: tileAnimRate
 * @default tileAnimRate
 * 
 * @param Save Key
 * @parent --- Advanced ---
 * @type string
 * @desc Property key for save contents.
 * Default: TileAnimExt
 * @default TileAnimExt
 */
//#endregion

(function() {
'use strict';

    const NAMESPACE   = 'TileAnimExt';
    const PLUGIN_NAME = 'Cae_' + NAMESPACE;
    const ERR_PRE     = PLUGIN_NAME + '.js ';
    const ERR_NOPARAM = ERR_PRE + 'could not find its parameters!\nCheck the plugin file is named correctly and try again.';
    const WARN_BADPARAM = ERR_PRE + 'encountered bad value for parameter "%1".\nAsserting default value: ';

    window.CAE = window.CAE || {};      // Author namespace

    (($, U) => {

        Object.defineProperty($, 'VERSION', { value: 1.3 });    // Version declaration
        window.Imported = window.Imported || {};                // Import namespace
        Imported[PLUGIN_NAME] = $.VERSION;                      // Import declaration

    // ======== Parameter stuff ======== //

        void (p => {

            if (!p) { SceneManager.showDevTools(); throw new Error(ERR_NOPARAM); };

            /**
             * @param {String} json - Stringified array input
             * @param {Number[]} dFault - Default value to assign if input is invalid
             * @param {String} warnMsg - Console warning message if input is invalid
             * @returns {Number[]} Array of frame indices representing an animation sequence.
             */
            $.parseSeq = function(json = '[]', dFault = [0], warnMsg = WARN_BADPARAM.format(json)) {
                let isBad = false;
                const res = JSON.parse(String(json)).map(n => {
                    if (isNaN(n)) isBad = true;
                    return parseInt(n, 10);
                });
                if (isBad || !res.length) {
                    console.warn(warnMsg + ' ' + dFault);
                    return dFault;
                }
                return res;
            };

            /**
             * @param {String} key - Plugin parameter key
             * @param {Number[]} dFault - Default animation sequence, returned if parameter value is invalid
             * @returns {Number[]} Specified animation frame sequence.
             */
            $.parseSeqParam = function(key, dFault) {
                return $.parseSeq(p[key], dFault, WARN_BADPARAM.format(key));
            };

            /**
             * Sets tile animation rate.
             * @param {Number|String} rate - Numberlike value to assign
             */
            $.setRate = function(rate) {
                if (isNaN(rate)) rate = p['Tile Animation Rate'];
                $.rate = parseInt(rate, 10) || 0;
                return true;
            };

            /**
             * Used to validate input for setAnimX and setAnimY methods.
             * @param {any} arr - Input "array"
             * @param {Number[]} dFault - Default value: returned if input is undefined
             * @returns {Number[]} Frame sequence; undefined if input is not an array.
             */
            $.setAnimTarget = function(arr, dFault) {
                if (arr === undefined) return dFault;
                if (!Array.isArray(arr)) return;
                else return arr;
            };

            /**
             * Sets "normal" tile animation frame sequence
             * @param {Number[]|String[]} arr - Numberlike array to assign
             */
            $.setAnimX = function(arr) {
                const res = $.setAnimTarget(arr, $.parseSeqParam('Tile Anim Sequence', [0, 1, 2, 1]));
                if (res) $.animX = res;
                return !!res;
            };

            /**
             * Sets waterfall tile animation frame sequence
             * @param {Number[]|String[]} arr - Numberlike array to assign
             */
            $.setAnimY = function(arr) {
                const res = $.setAnimTarget(arr, $.parseSeqParam('Waterfall Anim Sequence', [0, 1, 2]));
                if (res) $.animY = res;
                return !!res;
            };

            $.setRate();
            $.setAnimX();
            $.setAnimY();
            $.label = p['Tile Animation Option'];
            $.save  = p['Add Save Data'] === 'true';

            Object.defineProperty($, 'CONFIG_SYM', { value: p['Config Key'] || 'tileAnimRate' });
            Object.defineProperty($, 'SAVE_PROP',  { value: p['Save Property'] || NAMESPACE })

        })($.params = PluginManager.parameters(PLUGIN_NAME));

    // ======== Utility (local) ======== //

        /**
         * @param {Number[]} ref - Frame ID reference array
         * @param {Number} af - Animation frame number
         * @returns {Number} Remapped frame ID for reference array.
         */
        $.getFrame  = function(ref, af) { return ref[af % ref.length]; };

        /**
         * @param {Number} af - Animation frame number
         * @returns {Number} Remapped frame ID for "normal" anim sequence.
         */
        $.getFrameX = function(af)      { return $.getFrame($.animX, af); };

        /**
         * @param {Number} af - Animation frame number
         * @returns {Number} Remapped frame ID for waterfall anim sequence.
         */
        $.getFrameY = function(af)      { return $.getFrame($.animY, af); };

        /** @returns {{rate:Number,x:Number[],y:Number[]}} Tile rate and sequence data for save files. */
        $.mkSave = function() { return { rate: $.rate, x: $.animX, y: $.animY }; };

        /**
         * Extracts given save file data to appropriate plugin variables.
         * @param {Object} contents - Object representing contents extracted from save file.
         */
        $.extractSave = function(contents) {
            const data = contents[$.SAVE_PROP] || {};
            $.setRate(data.rate);
            $.setAnimX(data.x);
            $.setAnimY(data.y);
        };

    // ======== Plugin Commands ======== //

        $.com = {
            /** Plugin command! Set tile animation rate. */
            setRate: function(args) { $.setRate(args.Rate); },
            /** Plugin command! Reset tile animation rate to plugin default. */
            resetRate: function(args) { $.setRate(); },
            /** Plugin command! Set tile animation sequence. */
            setAnimSeq: function(args) {
                const warnMsg = WARN_BADPARAM.format('Command: Set Animation Sequence: Sequence');
                const seq = $.parseSeq(args.Sequence, '', warnMsg);
                if (!seq) return;
                switch (args.Type.toLowerCase()) {
                    case 'x': case 'normal':
                        return $.setAnimX(seq);
                    case 'y': case 'waterfall':
                        return $.setAnimY(seq);
                    default:
                        return false;
                }
            },
            /** Plugin command! Reset tile animation sequence to plugin default. */
            resetAnimSeq: function(args) {
                switch (args.Type.toLowerCase()) {
                    case 'x': case 'normal':
                        return $.setAnimX();
                    case 'y': case 'waterfall':
                        return $.setAnimY();
                    default:
                        return false;
                }
            }
        };
        PluginManager.registerCommand(PLUGIN_NAME, 'Set Rate', $.com.setRate);
        PluginManager.registerCommand(PLUGIN_NAME, 'Reset Rate', $.com.resetRate);
        PluginManager.registerCommand(PLUGIN_NAME, 'Set Animation Sequence', $.com.setAnimSeq);
        PluginManager.registerCommand(PLUGIN_NAME, 'Reset Animation Sequence', $.com.resetAnimSeq);

    // ============ Extends ============ //

        $.active = true;
        Object.defineProperty(ConfigManager, $.CONFIG_SYM, {
            get: ( ) => $.active,
            set: (v) => $.active = v,
            configurable: true
        });

    // ========== Alterations ========== //

        // Override! Two lines edited, everything replaced... >_>
        Tilemap.prototype._addAutotile = function(layer, tileId, dx, dy) {
            const kind = Tilemap.getAutotileKind(tileId);
            const shape = Tilemap.getAutotileShape(tileId);
            const tx = kind % 8;
            const ty = Math.floor(kind / 8);
            let setNumber = 0;
            let bx = 0;
            let by = 0;
            let autotileTable = Tilemap.FLOOR_AUTOTILE_TABLE;
            let isTable = false;        
        /* breathe */
            if (Tilemap.isTileA1(tileId)) {
                const waterSurfaceIndex = $.getFrameX(this.animationFrame);     // <- edit 1 of 2
                setNumber = 0;
                if (kind === 0) {
                    bx = waterSurfaceIndex * 2; by = 0;
                } else if (kind === 1) {
                    bx = waterSurfaceIndex * 2; by = 3;
                } else if (kind === 2) {
                    bx = 6; by = 0;
                } else if (kind === 3) {
                    bx = 6; by = 3;
                } else {
                    bx = Math.floor(tx / 4) * 8;
                    by = ty * 6 + (Math.floor(tx / 2) % 2) * 3;
                    if (kind % 2 === 0) {
                        bx += waterSurfaceIndex * 2;
                    } else {
                        bx += 6;
                        autotileTable = Tilemap.WATERFALL_AUTOTILE_TABLE;
                        by += $.getFrameY(this.animationFrame);                 // <- edit 2 of 2
                    }
                }
            } else if (Tilemap.isTileA2(tileId)) {
                setNumber = 1; bx = tx * 2; by = (ty - 2) * 3;
                isTable = this._isTableTile(tileId);
            } else if (Tilemap.isTileA3(tileId)) {
                setNumber = 2; bx = tx * 2; by = (ty - 6) * 2;
                autotileTable = Tilemap.WALL_AUTOTILE_TABLE;
            } else if (Tilemap.isTileA4(tileId)) {
                setNumber = 3; bx = tx * 2;
                by = Math.floor((ty - 10) * 2.5 + (ty % 2 === 1 ? 0.5 : 0));
                if (ty % 2 === 1) autotileTable = Tilemap.WALL_AUTOTILE_TABLE;
            }
        /* breathe */
            const table = autotileTable[shape];
            const w1 = (this.tileWidth ?? this._tileWidth) / 2;
            const h1 = (this.tileHeight ?? this._tileHeight) / 2;
            for (let i = 0; i < 4; i++) {
                const qsx = table[i][0];
                const qsy = table[i][1];
                const sx1 = (bx * 2 + qsx) * w1;
                const sy1 = (by * 2 + qsy) * h1;
                const dx1 = dx + (i % 2) * w1;
                const dy1 = dy + Math.floor(i / 2) * h1;
                if (isTable && (qsy === 1 || qsy === 5)) {
                    const qsx2 = qsy === 1 ? (4 - qsx) % 4 : qsx;
                    const qsy2 = 3;
                    const sx2 = (bx * 2 + qsx2) * w1;
                    const sy2 = (by * 2 + qsy2) * h1;
                    layer.addRect(setNumber, sx2, sy2, dx1, dy1, w1, h1);
                    layer.addRect(setNumber, sx1, sy1, dx1, dy1 + h1 / 2, w1, h1 / 2);
                } else {
                    layer.addRect(setNumber, sx1, sy1, dx1, dy1, w1, h1);
                }
            }
        };

        $.alias = $.alias || {};        // This plugin's alias namespace

        // Alias! Adjust animation count 
        void (alias => {
            Tilemap.prototype.update = function() {
                if ($.active) this.animationCount += $.rate / 2;    // animationCount cuts off at 30 so divide by 2 here
                this.animationCount -= 1;                           // Cancel out +1 from default code
                alias.apply(this, arguments);
            };
        })($.alias.Tilemap_update = Tilemap.prototype.update);

        void (() => { if (!$.label) return;

            // Alias! Load new flag
            void (alias => {
                ConfigManager.makeData = function() {
                    const config = alias.apply(this, arguments);
                    const k = $.CONFIG_SYM;
                    config[k] = this[k];
                    return config;
                };
            })($.alias.ConfigManager_makeData = ConfigManager.makeData);

            // Alias! Save new flag
            void (alias => {
                ConfigManager.applyData = function(config) {
                    alias.apply(this, arguments);
                    const k = $.CONFIG_SYM;
                    if (config[k] === undefined) this[k] = true;
                    else this[k] = this.readFlag(config, k);
                };
            })($.alias.ConfigManager_applyData = ConfigManager.applyData);

            // Alias! Add to options menu
            void (alias => {
                Window_Options.prototype.addGeneralOptions = function() {
                    alias.apply(this, arguments);
                    this.addCommand($.label, $.CONFIG_SYM);
                };
            })($.alias.Window_Options_addGeneralOptions = Window_Options.prototype.addGeneralOptions);

            // Alias! "Register" additional command with scene so the window scales correctly.
            void (alias => {
                Scene_Options.prototype.maxCommands = function() {
                    return alias.apply(this, arguments) + 1;
                };
            })($.alias.Scene_Options_maxCommands = Scene_Options.prototype.maxCommands);

        })();

        // Alias! Initialise tile rate/sequences on new game.
        void (alias => {
            DataManager.createGameObjects = function() {
                alias.apply(this, arguments);
                $.setRate(), $.setAnimX(), $.setAnimY();
            };
        })($.alias.DataManager_createGameObjects = DataManager.createGameObjects);

        void (() => { if (!$.save) return;

            // Alias! Include tile rate/sequence data in save files.
            void (alias => {
                DataManager.makeSaveContents = function() {
                    const contents = alias.apply(this, arguments);
                    contents[$.SAVE_PROP] = $.mkSave();
                    return contents;
                };
            })($.alias.DataManager_makeSaveContents = DataManager.makeSaveContents);

            // Alias! Extract tile rate/sequence data from save files
            void (alias => {
                DataManager.extractSaveContents = function(contents) {
                    alias.apply(this, arguments);
                    $.extractSave(contents);
                };
            })($.alias.DataManager_extractSaveContents = DataManager.extractSaveContents);

        })();

    })(CAE[NAMESPACE] = CAE[NAMESPACE] || {}, CAE.Utils = CAE.Utils || {});

})();