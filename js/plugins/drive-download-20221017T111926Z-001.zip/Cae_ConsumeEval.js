// ==================================================
// Cae_ConsumeEval.js
// ==================================================

/**
 * @file Cae_ConsumeEval.js (RMMZ)
 * Specify conditions for items to be consumed on use.
 * @author Caethyril
 * @version 1.0
 */

//#region Plugin header
/*:
 * @target MZ
 * @plugindesc v1.0 - Specify conditions for items to be consumed on use.
 * @author Caethyril
 * @url https://forums.rpgmakerweb.com/index.php?threads/caethyrils-mz-plugins.125657/
 * 
 * @help Features:
 *   Add a notetag to an item to determine when it should be consumed.
 * 
 * Item Notetag:
 *        <ConsumeEval: code>
 *   Replace "code" with valid JavaScript.
 *   Note: "code" must not include the ">" character.
 *    - You can invert expressions and use "<" instead where necessary.
 * 
 *   Local variables:
 *    - item        $dataItems entry of item being used
 *    - user        user of item (in menu this is highest pha actor)
 *    - targets     array of targets
 *    - target      equivalent to targets[0] (i.e. the first target)
 * 
 *   The item will be consumed on use unless ConsumeEval returns a falsy value.
 *   Tagged items should be marked as Consumable: Yes in the database.
 * 
 *   Examples:
 *     <ConsumeEval: 20 <= $gameVariables.value(1)>
 *       - item consumes on use if variable #1 is 20 or more.
 *     <ConsumeEval: user.pha < 2>
 *       - item consumes on use if user's PHA stat is less than 200%.
 *     <ConsumeEval: (target.hp < target.mhp) && (50 < user.luk)>
 *       - item consumes on use if target's HP < 100% and user's LUK > 50.
 *
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
 * Terms of use:
 *   This plugin is free to use and/or modify, under these conditions:
 *     - None of the original plugin header is removed.
 *     - Credit is given to Caethyril for the original work.
 * 
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
 * Compatibility:
 *   Aliases:   Game_Action:
 *                makeTargets
 *              Game_Party:
 *                consumeItem
 *   This plugin does not add data to save files.
 * 
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
 * Changelog:
 *   v1.0 (2020-09-05): Initial release! Rewrite of RMMV version.
 * 
 * @param --- Advanced ---
 * @type select
 * @desc Advanced internal configuration options.
 * 
 * @param Notetag: ConsumeEval
 * @parent --- Advanced ---
 * @type string
 * @desc This tag's key/name.
 * Default: ConsumeEval
 * @default ConsumeEval
 */
//#endregion

(function() {
'use strict';

    const NAMESPACE   = 'ConsumeEval';
    const PLUGIN_NAME = 'Cae_' + NAMESPACE;
    const ERR_PRE     = PLUGIN_NAME + '.js ';
    const ERR_NOPARAM = ERR_PRE + 'could not find its parameters!\nCheck the plugin file is named correctly and try again.';
    const WARN_BADKEY = ERR_PRE + 'could not use name "%1" for "%2" notetag. Reverting to default: "%3".';

    window.CAE = window.CAE || {};      // Author namespace

    (($, U) => {

        Object.defineProperty($, 'VERSION', { value: 1.0 });    // Version declaration
        window.Imported = window.Imported || {};                // Import namespace
        Imported[PLUGIN_NAME] = $.VERSION;                      // Import declaration

    // ======== Utility (share) ======== //
    // ======== Parameter stuff ======== //

        void (p => {

            if (!p) { SceneManager.showDevTools(); throw new Error(ERR_NOPARAM); };

            $.parseTagKey = function(paramName) {
                const key = p['Notetag: ' + paramName];
                const dFault = paramName;
                if (!key || key.includes('>') || key.includes(':')) {
                    console.warn(WARN_BADKEY.format(key, paramName, dFault));
                    return dFault;
                }
                return key;
            };

            $.tags = {
                consumeEval: $.parseTagKey('ConsumeEval')
            };

        })($.params = PluginManager.parameters(PLUGIN_NAME));

    // ========= Init Routines ========= //
    // ======== Utility (local) ======== //

        /** Remembers targets of most recent action. */
        $.targets = [];

        /** @returns {Scene_Base} Active scene. */
        $.sceneNow = function() { return SceneManager._scene; };

        /**
         * @param {Scene_Base} scene - Scene to compare
         * @returns {Boolean} True iff active scene inherits from specified scene.
         */
        $.isScene = function(scene) { return $.sceneNow() instanceof scene; };
        
        /**
         * Gets item user.
         * - Menu: first actor with highest PHA
         * - Battle: acting actor
         * @returns {Game_Actor} Appropriate Game_Actor reference, else undefined.
         */
        $.getItemUser = function() {
            if ($.isScene(Scene_Battle)) {            // Battle
                return BattleManager._subject;
            } else if ($.isScene(Scene_Item)) {        // Inventory
                return $.sceneNow().user();
            }
            return;    // Unknown
        };

        /** @returns {Game_Battler[]} Current item targets. */
        $.getItemTargets = function() {
            if ($.isScene(Scene_Battle)) {            // Battle
                return $.targets;
            } else if ($.isScene(Scene_Item)) {        // Inventory
                return $.sceneNow().itemTargetActors();
            }
            return;    // Unknown
        };

        /**
         * @param {String} code - JavaScript to evaluate
         * @param {Object} item - $dataItems entry for this item
         * @returns {Boolean} Eval result.
         */
        $.testEval = function(code, item) {
            if (!code) return true;
            try {
                const user    = $.getItemUser();
                const targets = $.getItemTargets();
                const target  = targets[0];
                return eval(code);
            } catch(ex) {
                console.error('Cae_ConsumeItem.js EVAL ERROR:\n\n' + code);
                return true;
            }
        };

        /**
         * @param {Object} item - $dataItems entry from which tag is to be retrieved
         * @returns {String} This plugin's ConsumeEval notetag, else undefined.
         */
        $.getConsumeTag = function(item) { return item?.meta?.[$.tags.consumeEval]; };

    // ======== Plugin Commands ======== //
    // ============ Extends ============ //
    // ========== Alterations ========== //

        $.alias = $.alias || {};        // This plugin's alias namespace

        // Alias! Grab the targets before the BattleManager shifts them into oblivion.
        void (alias => {
            Game_Action.prototype.makeTargets = function() {
                const t = alias.apply(this, arguments);
                $.targets = t.slice();
                return t;
            };
        })($.alias.Game_Action_makeTargets = Game_Action.prototype.makeTargets);

        // Alias! Check tag before consuming item.
        void (alias => {
            Game_Party.prototype.consumeItem = function(item) {
                if ($.testEval($.getConsumeTag(item), item)) alias.apply(this, arguments);
            };
        })($.alias.Game_Party_consumeItem = Game_Party.prototype.consumeItem);

    })(CAE[NAMESPACE] = CAE[NAMESPACE] || {}, CAE.Utils = CAE.Utils || {});

})();