// ==================================================
// Cae_TimeStopBattlers.js
// ==================================================

/**
 * @file Cae_TimeStopBattlers.js (RMMZ)
 * Freeze visual updates of battlers affected by certain states.
 * @author Caethyril
 * @version 1.0
 */

//#region Plugin header
/*:
 * @target MZ
 * @plugindesc v1.0 - Freeze motion updates of battlers affected by certain states.
 * @author Caethyril
 * @url https://forums.rpgmakerweb.com/index.php?threads/caethyrils-mz-plugins.125657/
 * 
 * @help Features:
 *   Add notetags to states to designate them "no-motion" states.
 *   Battlers affected by one or more of these states will be visually frozen.
 * 
 * State Notetag:
 *        <NoMotion>
 *   - battlers affected by this state will be visually motionless
 *
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
 * Terms of use:
 *   This plugin is free to use and/or modify, under these conditions:
 *     - None of the original plugin header is removed.
 *     - Credit is given to Caethyril for the original work.
 * 
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
 * Compatibility:
 *   Aliases:   Sprite_Actor:
 *                startMotion, updateMotion
 *   This plugin does not add data to save files.
 * 
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
 * Changelog:
 *   v1.0 (2020-09-13): Initial release! Rewrite of RMMV version.
 * 
 * @param --- Advanced ---
 * @type select
 * @desc Advanced internal configuration options.
 * 
 * @param Notetag: NoMotion
 * @parent --- Advanced ---
 * @type string
 * @desc The name of the NoMotion notetag referenced by this plugin. Case-sensitive!
 * @default NoMotion
 */
//#endregion

(function() {
'use strict';

    const NAMESPACE   = 'TimeStopBattlers';
    const PLUGIN_NAME = 'Cae_' + NAMESPACE;
    const ERR_PRE     = PLUGIN_NAME + '.js ';
    const ERR_NOPARAM = ERR_PRE + 'could not find its parameters!\nCheck the plugin file is named correctly and try again.';
    const WARN_BADVAL = ERR_PRE + 'could not use "%1" %2 value "%3". Reverting to default: "%4".';

    window.CAE = window.CAE || {};      // Author namespace

    (($, U) => {

        Object.defineProperty($, 'VERSION', { value: 1.0 });    // Version declaration
        window.Imported = window.Imported || {};                // Import namespace
        Imported[PLUGIN_NAME] = $.VERSION;                      // Import declaration

    // ======== Utility (share) ======== //
    // ======== Parameter stuff ======== //

        void (p => {

            if (!p) { SceneManager.showDevTools(); throw new Error(ERR_NOPARAM); };

            $.parse = {
                tag: function(name) {
                    const FORBID = ['>',':'];
                    const tag = p['Notetag: ' + name];
                    const dFault = name;
                    if (!tag || FORBID.some(f => tag.includes(f))) {
                        console.warn(WARN_BADVAL.format(name, 'notetag', tag, dFault));
                        return dFault;
                    }
                    return tag;
                }
            };

            $.tags = {
                noMotion: $.parse.tag('NoMotion')
            };

        })($.params = PluginManager.parameters(PLUGIN_NAME));

    // ========= Init Routines ========= //
    // ======== Utility (local) ======== //

        /**
         * @param {Game_Battler} char - Game_Battler instance to reference
         * @returns {Boolean} True iff given character is affected by at least one "NoMotion" state.
         */
        $.isNoMotion = function(char) { return char?.states().some(s => s.meta[$.tags.noMotion]); };

    // ======== Plugin Commands ======== //
    // ============ Extends ============ //
    // ========== Alterations ========== //

        $.alias = $.alias || {};        // This plugin's alias namespace

        // Alias! Motionless characters should not visually change motions.
        void (alias => {
            Sprite_Actor.prototype.startMotion = function() {
                if (!$.isNoMotion(this._battler)) alias.apply(this, arguments);
            };
        })($.alias.Sprite_Actor_startMotion = Sprite_Actor.prototype.startMotion);

        // Alias! Motionless characters should not get motion frame updates.
        void (alias => {
            Sprite_Actor.prototype.updateMotion = function() {
                if (!$.isNoMotion(this._battler)) alias.apply(this, arguments);
            };
        })($.alias.Sprite_Actor_updateMotion = Sprite_Actor.prototype.updateMotion);

        // + translational movement?

    })(CAE[NAMESPACE] = CAE[NAMESPACE] || {}, CAE.Utils = CAE.Utils || {});

})();