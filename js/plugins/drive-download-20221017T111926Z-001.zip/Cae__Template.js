// ==================================================
// Cae__Template.js
// ==================================================

/**
 * @file Cae__Template.js (RMMZ)
 * Description goes here
 * @author Caethyril
 * @version 0.0
 */

//#region Plugin header
/*:
 * @target MZ
 * @plugindesc v0.0 - Description goes here
 * @author Caethyril
 * @url https://forums.rpgmakerweb.com/index.php?threads/caethyrils-mz-plugins.125657/
 * @base
 * @orderAfter
 * @orderBefore
 * 
 * @help Features:
 *   Description~
 * 
 * Help section:
 *   textextextextext
 * 
 * Plugin Command:
 *   Command 1 - description
 *
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
 * Terms of use:
 *   This plugin is free to use and/or modify, under these conditions:
 *     - None of the original plugin header is removed.
 *     - Credit is given to Caethyril for the original work.
 * 
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
 * Compatibility:
 *   Overrides: Name:
 *                method, method, method
 *   Aliases:   Name:
 *                method, method
 *   Defines:   Name:
 *                method
 *   This plugin does not add data to save files.
 * 
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
 * Changelog:
 *   v1.0 (YYYY-MM-DD): Initial release! Rewrite of RMMV version.
 * 
 * @command Command 1
 * @desc What this command does
 * 
 * @arg Com 1 Arg 1
 * @type number
 * @min 1
 * @max 10
 * @decimals 2
 * @desc Argument 1 of command 1
 * @default 5
 * 
 * @arg Com 1 Arg 2
 * @type select
 * @option A
 * @option B
 * @option C
 * @desc Argument 2 of command 1
 * @default A
 * 
 * @param Param 1
 * @type combo[]
 * @option Red
 * @option Orange
 * @option Yellow
 * @option Green
 * @option Blue
 * @option Indigo
 * @option Violet
 * @desc Plugin parameter 1
 * @default Red
 * 
 * @param Param 2
 * @type struct<CaeTemplateType>
 * @parent Param 1
 * @desc Plugin parameter 2
 * 
 * @param --- Advanced ---
 * @type select
 * @desc Advanced internal configuration options.
 */
// =========================
/*~struct~TemplateType:
 * @param Struct Param 1
 * @type switch
 * @desc Struct param 1
 * @default 0
 * 
 * @param Struct Param 2
 * @type variable
 * @desc Struct param 2
 * @default 0
 */
//#endregion

(function() {
'use strict';

    const NAMESPACE   = '_Template';
    const PLUGIN_NAME = 'Cae_' + NAMESPACE;
    const ERR_PRE     = PLUGIN_NAME + '.js ';
    const ERR_NOPARAM = ERR_PRE + 'could not find its parameters!\nCheck the plugin file is named correctly and try again.';

    window.CAE = window.CAE || {};      // Author namespace

    (($, U) => {

        Object.defineProperty($, 'VERSION', { value: 0.0 });    // Version declaration
        window.Imported = window.Imported || {};                // Import namespace
        Imported[PLUGIN_NAME] = $.VERSION;                      // Import declaration

    // ======== Utility (share) ======== //

        void (k => { if (U[k]) return;
            /**
             * Asks a question!
             * @param {String} a - Message displayed
             * @returns {Boolean} True iff user chose "OK".
             */
            U[k] = function(a) { return confirm(a); };
        })('templateFunc')

    // ======== Parameter stuff ======== //

        $.params = PluginManager.parameters(PLUGIN_NAME);
        if (!$.params) {
            SceneManager.showDevTools();
            throw new Error(ERR_NOPARAM);
        }

        $.param1 = JSON.parse($.params['Param 1']);
        $.param2 = JSON.parse($.params['Param 2']);
        $.switch = parseInt($.param2['Struct Param 1'], 10);
        $.varble = parseInt($.param2['Struct Param 2'], 10);

    // ========= Init Routines ========= //
    // ======== Utility (local) ======== //
    // ======== Plugin Commands ======== //

        $.com = {
            com1: function(args) { console.table(args); SceneManager.showDevTools(); }
        };
        PluginManager.registerCommand(PLUGIN_NAME, 'Command 1', $.com.com1);

    // ============ Extends ============ //
    // ========== Alterations ========== //

        $.alias = $.alias || {};        // This plugin's alias namespace

        void (alias => {
            Game_Player.prototype.increaseSteps = function() {
                alias.apply(this, arguments);
                console.log('step');
            };
        })($.alias.Game_Player_increaseSteps = Game_Player.prototype.increaseSteps);

    })(CAE[NAMESPACE] = CAE[NAMESPACE] || {}, CAE.Utils = CAE.Utils || {});

})();