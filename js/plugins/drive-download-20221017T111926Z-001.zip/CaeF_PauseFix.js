/*:
 * @target MZ
 * @plugindesc Pause/resume audio (and Effekseer) with the game loop.
 * @author Caethyril
 * @url https://forums.rpgmakerweb.com/index.php?threads/141642/
 * @help Free to use and/or modify for any project. No credit required.
 */

(() => {
'use strict';

    let isActive = true;

    const SHOULD_LOOP = Symbol();

    const getEffekseerHandles = function() {
        return (SceneManager._scene._spriteset?._animationSprites || [])
                .map(s => s._handle)
                .filter(h => h);
    };

    const pauseEffekseer = function(handles, active) {
        handles.forEach(h => h.setPaused(!active));
    };

    const getAudioContext = function() {
        return WebAudio._context;
    };

    const pauseAudio = function(context, active) {
        if (active) context.resume();
        else        context.suspend();
    };

    const updateActive = function() {
        if (true)
            // 1.4.4 core script does not pause audio
            pauseAudio(getAudioContext(), isActive);
        if (!Utils.checkRMVersion("1.4.0"))
            // apply for pre-1.4.0 core script only
            pauseEffekseer(getEffekseerHandles(), isActive);
    };

    const onAudioEnd = function(index) {
        if (this[SHOULD_LOOP]) {
            // This is the original onended event handler, for encrypted audio loops.
            this._createSourceNode(index);
            this._startSourceNode(index);
        } else {
            // This replaces the original setTimeout method
            // so that end timers trigger when they are supposed to.
            const endTime = this._startTime + this._totalTime / this._pitch;
            if (WebAudio._currentTime() >= endTime)
                this.stop();
        }
    };

    // Also update the audio's "active" status.
    const alias = SceneManager.updateScene;
    SceneManager.updateScene = function() {
        const active = this.isGameActive();
        if (isActive !== active) {
            isActive = active;
            updateActive();
        }
        alias.apply(this, arguments);
    };

    // Assign "onended" event handler to onAudioEnd (see above).
    // A new flag (SHOULD_LOOP symbol) is set for looped encrypted audio.
    // This flag determines the behaviour of onAudioEnd.
    WebAudio.prototype._startSourceNode = function(index) {
        delete this[SHOULD_LOOP];                                   // <- edit 1 of 3
        const sourceNode = this._sourceNodes[index];
        const seekPos = this.seek();
        const currentTime = WebAudio._currentTime();
        const loop = this._loop;
        const loopStart = this._loopStartTime;
        const loopLength = this._loopLengthTime;
        const loopEnd = loopStart + loopLength;
        const pitch = this._pitch;
        let chunkStart = 0;
        for (let i = 0; i < index; i++) {
            chunkStart += this._buffers[i].duration;
        }
        const chunkEnd = chunkStart + sourceNode.buffer.duration;
        let when = 0;
        let offset = 0;
        let duration = sourceNode.buffer.duration;
        if (seekPos >= chunkStart && seekPos < chunkEnd - 0.01) {
            when = currentTime;
            offset = seekPos - chunkStart;
        } else {
            when = currentTime + (chunkStart - seekPos) / pitch;
            offset = 0;
            if (loop) {
                if (when < currentTime - 0.01) {
                    when += loopLength / pitch;
                }
                if (seekPos >= loopStart && chunkStart < loopStart) {
                    when += (loopStart - chunkStart) / pitch;
                    offset = loopStart - chunkStart;
                }
            }
        }
        if (loop && loopEnd < chunkEnd) {
            duration = loopEnd - chunkStart - offset;
        }
        if (this._shouldUseDecoder()) {
            if (when >= currentTime && offset < duration) {
                sourceNode.loop = false;
                sourceNode.start(when, offset, duration);
                if (loop && chunkEnd > loopStart) {
                    this[SHOULD_LOOP] = true;                       // <- edit 2 of 3
                    sourceNode.onended = onAudioEnd.bind(this);     // <- edit 3 of 3
                }
            }
        } else {
            if (when >= currentTime && offset < sourceNode.buffer.duration) {
                sourceNode.start(when, offset);
            }
        }
        chunkStart += sourceNode.buffer.duration;
    };
    
    // Rewritten: end timer now fires via "onended" event.
    // This allows it to respect AudioContext timing changes, e.g. pause/resume.
    WebAudio.prototype._createEndTimer = function() {
        if (!this._loop)
            // (Note to self: multiple source nodes are used for encrypted audio.)
            this._sourceNodes.forEach((source, n) => {
                source.onended = onAudioEnd.bind(this, n);
            }, this);
        // original:
        // if (this._sourceNodes.length > 0 && !this._loop) {
        //     const endTime = this._startTime + this._totalTime / this._pitch;
        //     const delay = endTime - WebAudio._currentTime();
        //     this._endTimer = setTimeout(this.stop.bind(this), delay * 1000);
        // }
    };

})();