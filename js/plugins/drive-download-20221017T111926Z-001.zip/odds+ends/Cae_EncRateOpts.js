// ==================================================
// Cae_EncRateOpts.js
// ==================================================

/**
 * @file Cae_EncRateOpts.js (RMMZ)
 * Adds an in-game setting to Scene_Options to control random encounter rate.
 * @author Caethyril
 * @version 1.1
 */

//#region Plugin header
/*:
 * @target MZ
 * @plugindesc v1.1 - Adds an in-game option to adjust random encounter rate.
 * @author Caethyril
 * @url https://forums.rpgmakerweb.com/index.php?threads/125657/
 * @help Features:
 *    Add an in-game encounter rate setting to the options menu!
 *    Customise available rates and display via the plugin parameters.
 * 
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
 * Terms of use:
 *   This plugin is free to use and/or modify, under these conditions:
 *     - None of the original plugin header is removed.
 *     - Credit is given to Caethyril for the original work.
 * 
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
 * Compatibility:
 *   Aliases:   ConfigManager:
 *                makeData, applyData
 *              Game_Player:
 *                encounterProgressValue
 *              Scene_Options:
 *                maxCommands
 *              Window_Options:
 *                addGeneralOptions, statusText,
 *                processOk, cursorLeft, cursorRight
 *   Adds a property to the ConfigManager (customisable).
 *   This plugin does not otherwise add data to save files.
 * 
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
 * Changelog:
 *   v1.1 (2021-03-25): Fixed - Default Index should now apply correctly.
 *                      Minor improvements to code modularity and readability.
 *   v1.0 (2021-03-24): Initial release!
 * 
 * @param Option Name
 * @type string
 * @desc The display name for the in-game encounter rate option.
 * @default Encounter Rate
 * 
 * @param Values
 * @type struct<EncRateOptType>[]
 * @desc Available values and their display names, in display order.
 * @default ["{\"Rate\":\"0.00\",\"Display Name\":\"\"}","{\"Rate\":\"50.00\",\"Display Name\":\"\"}","{\"Rate\":\"100.00\",\"Display Name\":\"\"}","{\"Rate\":\"150.00\",\"Display Name\":\"\"}","{\"Rate\":\"200.00\",\"Display Name\":\"\"}"]
 * 
 * @param Default Index
 * @type number
 * @min 0
 * @desc Index of the value that is selected by default.
 * Note: 0 = first value.
 * @default 2
 * 
 * @param --- Advanced ---
 * @type select
 * @desc Advanced configuration options for this plugin!
 * 
 * @param Config Property
 * @parent --- Advanced ---
 * @type string
 * @desc Name of the property used to store the selected encounter rate.
 * @default encounterRate
 */
// =========================
/*~struct~EncRateOptType:
 * @param Rate
 * @type number
 * @min 0
 * @decimals 2
 * @desc Encounter rate multiplier.
 * 0 = 0% (none); 50 = 50% (half); 200 = 200% (double); etc.
 * @default 0
 * 
 * @param Display Name
 * @type string
 * @desc Text displayed for this value.
 * If blank, the value will be shown as a percentage.
 * @default
 */
//#endregion

(() => {
'use strict';

    const NAMESPACE   = 'EncRateOpts';
    const PLUGIN_NAME = 'Cae_' + NAMESPACE;
    const ERR_NOPARAM = PLUGIN_NAME + '.js could not find its parameters!\
                        \nCheck the plugin file is named correctly and try again.';

    window.CAE ||= {};         // Author namespace

    (($, U) => {

        Object.defineProperty($, 'VERSION', { value: 1.1 });    // Version declaration
        window.Imported ||= {};                                 // Import namespace
        Imported[PLUGIN_NAME] = $.VERSION;                      // Import declaration

        const SYM = Symbol();   // pointer to name of ConfigManager property

    // ======== Parameter stuff ======== //

        (p => { if (!p) { SceneManager.showDevTools(); throw new Error(ERR_NOPARAM); };

            $.n = p['Option Name'] || '';
            $.v = JSON.parse(p['Values']).map(s => {
                const o = JSON.parse(s);
                return {
                    r: Number(o.Rate) || 0,
                    n: String(o['Display Name'] || '').trim()
                };
            });
            $.d = parseInt(p['Default Index'], 10) || 0;

            Object.defineProperty($, SYM, { value: String(p['Config Property'] || '').trim() });

        })(PluginManager.parameters(PLUGIN_NAME));

    // ======== Utility (local) ======== //

        /**
         * Intended for use from Window_Options, a la isVolumeSymbol.
         * @param {String} symbol - Command symbol
         * @returns {Boolean} True iff symbol matches.
         */
        $.isEncRateSymbol = function(symbol) { return symbol === $.SYM; };

        /**
         * @param {Number} rate - Encounter rate value
         * @returns {String} Input value formatted as status text.
         */
        $.encRateStatusTextDefault = function(rate) { return rate + '%'; };

        /** @returns {String} Config status text for current encounter rate setting.  */
        $.encRateStatusText = function() {
            const i = ConfigManager[$.SYM];
            const V = $.v[i];
            if (V.n) return V.n;
            return $.encRateStatusTextDefault(V.r);
        };

        /**
         * Call in Window_Options context.
         * @param {Boolean} forward - True iff this is an increment operation
         * @param {Boolean} wrap - True iff should wrap
         */
        $.changeEncRate = function(forward, wrap) {
            const value = this.getConfigValue($.SYM);
            if (!wrap && (value === (forward ? $.v.length - 1 : 0))) return;
            this.changeValue($.SYM, value + (forward ? 1 : -1));
        };

    // ============ Extends ============ //

        // Add ConfigManager property corresponding to new option.
        Object.defineProperty(ConfigManager, $.SYM, {
            get: ( ) => this['_' + $.SYM] || 0,
            set: (v) => {
                if (!isNaN(v)) this['_' + $.SYM] = parseInt(v, 10).mod($.v.length);
            },
            configurable: true
        });
        ConfigManager[$.SYM] = $.d || 0;    // init to default value

    // ========== Alterations ========== //

        $.alias ||= {};

        // Alias! Include setting in config file.
        void (alias => {
            ConfigManager.makeData = function() {
                const config = alias.apply(this, arguments);
                config[$.SYM] = this[$.SYM];
                return config;
            };
        })($.alias.ConfigManager_makeData = ConfigManager.makeData);

        // Alias! Extract setting from config file or apply default.
        void (alias => {
            ConfigManager.applyData = function(config) {
                alias.apply(this, arguments);
                this[$.SYM] = config[$.SYM] !== undefined ? config[$.SYM] : $.d;
            };
        })($.alias.ConfigManager_applyData = ConfigManager.applyData);

        // Alias! Adjust default per-step encounter progress value.
        void (alias => {
            Game_Player.prototype.encounterProgressValue = function() {
                return alias.apply(this, arguments) * $.v[ConfigManager[$.SYM]].r / 100;
            };
        })($.alias.Game_Player_encounterProgressValue = Game_Player.prototype.encounterProgressValue);

        // Alias! Increase options window size if appropriate.
        void (alias => {
            Scene_Options.prototype.maxCommands = function() {
                return alias.apply(this, arguments) + 1;
            };
        })($.alias.Scene_Options_maxCommands = Scene_Options.prototype.maxCommands);

        // Alias! Add command to options window.
        void (alias => {
            Window_Options.prototype.addGeneralOptions = function() {
                alias.apply(this, arguments);
                this.addCommand($.n, $.SYM);
            };
        })($.alias.Window_Options_addGeneralOptions = Window_Options.prototype.addGeneralOptions);

        // Alias! Define custom display text for this option.
        void (alias => {
            Window_Options.prototype.statusText = function(index) {
                const symbol = this.commandSymbol(index);
                if ($.isEncRateSymbol(symbol))
                    return $.encRateStatusText(this.getConfigValue(symbol));
                return alias.apply(this, arguments);
            };
        })($.alias.Window_Options_statusText = Window_Options.prototype.statusText);

        // Alias! Define custom [OK] behaviour for this option.
        void (alias => {
            Window_Options.prototype.processOk = function() {
                const index = this.index();
                const symbol = this.commandSymbol(index);
                if ($.isEncRateSymbol(symbol)) {
                    $.changeEncRate.call(this, true, true);
                } else alias.apply(this, arguments);
            };
        })($.alias.Window_Options_processOk = Window_Options.prototype.processOk);

        // Alias! Define custom [<-] behaviour for this option.
        void (alias => {
            Window_Options.prototype.cursorLeft = function() {
                const index = this.index();
                const symbol = this.commandSymbol(index);
                if ($.isEncRateSymbol(symbol)) {
                    $.changeEncRate.call(this, false, false);
                } else alias.apply(this, arguments);
            };
        })($.alias.Window_Options_cursorLeft = Window_Options.prototype.cursorLeft);

        // Alias! Define custom [->] behaviour for this option.
        void (alias => {
            Window_Options.prototype.cursorRight = function() {
                const index = this.index();
                const symbol = this.commandSymbol(index);
                if ($.isEncRateSymbol(symbol)) {
                    $.changeEncRate.call(this, true, false);
                } else alias.apply(this, arguments);
            };
        })($.alias.Window_Options_cursorRight = Window_Options.prototype.cursorRight);

    })(CAE[NAMESPACE] ||= {}, CAE.Utils ||= {});

})();