/*:
 * @target MZ
 * @plugindesc Some core script changes
 * @help Changes how input works during messages:
 *   - no map/message fast-forward when holding OK during an event
 *   - trigger input to end a message (cannot just hold input)
 */

// Never put map scene into fast-forward mode.
// (Default: fast-forward when OK is held during an event.)
Scene_Map.prototype.isFastForward = function() { return false; };

// Do not show message quickly when OK/cancel is held during message.
Window_Message.prototype.updateShowFast = function() {};

// Do not trigger the message except when the button is initially pressed down.
// (Default: after 24 frames held, trigger repeats every 6 frames until released.)
Window_Message.prototype.isTriggered = function() {
    return (
        Input.isTriggered('ok') ||
        Input.isTriggered('cancel') ||
        TouchInput.isTriggered()
    );
};