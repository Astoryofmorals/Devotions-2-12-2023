/*:
 * @target MZ
 * @plugindesc No loop for victory motion.
 * @author Caethyril
 * @help Terms of use: free to use and/or modify for any project.
 */

// Override! Disable loop for victory motion.
Sprite_Actor.MOTIONS.victory.loop = false;

// Alias! Do not start wait motion during battle end phase.
(alias => {
    Sprite_Actor.prototype.startMotion = function(motionType) {
        if (motionType !== 'wait' || BattleManager._phase !== 'battleEnd') {
            alias.apply(this, arguments);
        }
    };
})(Sprite_Actor.prototype.startMotion);