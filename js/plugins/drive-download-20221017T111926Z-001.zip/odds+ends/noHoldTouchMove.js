/*:
 * @target MZ
 * @plugindesc Release touch to select a new destination.
 * @help Free to use and/or modify for any project, no credit required.
 */
void (alias => {
  Scene_Map.prototype.processMapTouch = function() {
    alias.apply(this, arguments);
    this._touchCount = 0;
  };
})(Scene_Map.prototype.processMapTouch);