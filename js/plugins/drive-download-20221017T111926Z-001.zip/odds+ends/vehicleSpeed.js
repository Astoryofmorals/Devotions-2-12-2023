/*:
 * @target MZ
 * @plugindesc Vehicle move speed adjustments
 * @author Caethyril
 * @help Features:
 *   - Define the default speeds for boat, ship, and airship vehicles.
 *   - Restores "get on" player move speed when leaving a vehicle.
 *     (By default move speed gets set to 4.)
 * 
 * @param Boat
 * @type number
 * @min 0.01
 * @decimals 2
 * @desc Default move speed of the boat vehicle.
 * @default 4
 * 
 * @param Ship
 * @type number
 * @min 0.01
 * @decimals 2
 * @desc Default move speed of the ship vehicle.
 * @default 5
 * 
 * @param Airship
 * @type number
 * @min 0.01
 * @decimals 2
 * @desc Default move speed of the airship vehicle.
 * @default 6
 */

// Override! Redefine vehicle move speeds.
void (() => {
    // Get parameters by plugin file name
    const p = PluginManager.parameters('vehicleSpeed');
    const boat = Number(p.Boat);
    const ship = Number(p.Ship);
    const airship = Number(p.Airship);
    // Override! Redefine vehicle move speeds according to params.
    Game_Vehicle.prototype.initMoveSpeed = function() {
        if (this.isBoat()) {
            this.setMoveSpeed(boat);
        } else if (this.isShip()) {
            this.setMoveSpeed(ship);
        } else if (this.isAirship()) {
            this.setMoveSpeed(airship);
        }
    };
})();

// Alias! Remember player speed when boarding.
(alias => {
    Game_Player.prototype.getOnVehicle = function() {
        this._preVehicleMoveSpeed = this.moveSpeed();
        alias.apply(this, arguments);
    };
})(Game_Player.prototype.getOnVehicle);

// Alias! Restore boarding speed to player on leaving.
(alias => {
    Game_Player.prototype.getOffVehicle = function() {
        alias.apply(this, arguments);
        if (this._preVehicleMoveSpeed) {
            this.setMoveSpeed(this._preVehicleMoveSpeed);
            delete this._preVehicleMoveSpeed;
        }
    };
})(Game_Player.prototype.getOffVehicle);