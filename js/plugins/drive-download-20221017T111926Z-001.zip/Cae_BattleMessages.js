// ==================================================
// Cae_BattleMessages.js
// ==================================================

/**
 * @file Cae_BattleMessages.js (RMMZ)
 * Customise various battle messages!
 * @author Caethyril
 * @version 1.0
 */

//#region Plugin header
/*:
 * @target MZ
 * @plugindesc v1.0 - Customise various battle messages!
 * @author Caethyril
 * @url https://forums.rpgmakerweb.com/index.php?threads/caethyrils-mz-plugins.125657/
 * 
 * @help Features:
 * 
 *   Enemy emerge messages:
 *    - Different styles are available:
 *       - troop style = one message using the name of the troop;
 *       - group style = one message using the leader's name;
 *       - enemy style = one message per enemy (default).
 *      These styles can be assigned globally or per-troop (tags).
 *    - Each enemy's emerge message can be customised via notetags.
 *    - Multiple enemies can display as a single "plural" name.
 *    - See the plugin parameters for global configuration options.
 *      Read on for details on available tags~
 *
 *   State messages:
 *    - Custom add/remove messages can be specified with notetags.
 * 
 *   Action count messages (new!):
 *    - References "Action Times +" trait of actors in battle.
 *    - Can display a message like "Reid has 3 actions this turn!"
 *    - Configure these messages via plugin parameters and/or notetags.
 * 
 * Tags:
 * 
 *   Troop Name Tags (use in the troop name):
 *       <group>
 *       <group: x>
 *     Troop member x (or a random one if unspecified) is group leader.
 *      - Use x = 0 for the first member of the troop.
 *      - Note that only one message will be shown per unique enemy name...
 *        E.g. bat, bat, bat, orc: use <group: 1> to make the orc leader.
 *     The troop's emerge message will use the group leader's name.
 *     Customise the default group emerge message via the plugin parameters.
 *
 *   Troop Name Tags (use in the troop name):
 *          <emerge:blah>
 *          <preemptive:blah>
 *          <surprise:blah>
 *     e.g. <emerge:%1 demands your money or your life!>
 *          <surprise:%1 never saw it coming!>
 *     Assign custom messages for emerge, preemptive, and surprise.
 *     Optional (emerge): use %1 = troop name (or group name if <group>).
 *     Optional (preemptive|surprise): use %1 = party name.
 *
 *   Enemy Notetag (use in an enemy's notebox):
 *          <emerge:blah>
 *     e.g. <emerge:A spooky %1 appears!>
 *     Assigns a custom per-enemy emerge message.
 *     Optional: use %1 for the enemy name.
 *
 *   Enemy Notetag (use in an enemy's notebox):
 *          <plural:blah>
 *     e.g. <plural:Flock of sheep>
 *     An alternative name for multiple enemies of this type.
 *     Optional: use %1 for the number of enemies.
 *     E.g. for a troop with 2 sheep:
 *          Default                  => "Sheep appeared!"
 *          <plural:%1 fluffy sheep> => "2 fluffy sheep appeared!"
 *
 *   Actor/Enemy Notetags (use in an actor/enemy's notebox):
 *          <state # add msg: blah>
 *          <state # rem msg: blah>
 *     e.g. <state 1 add msg:%1 is dead but not forgotten.>
 *     Assigns a custom add/remove state message; swap # for the state ID.
 *
 *   Actor Notetag (use in an actor's notebox):
 *          <action count msg:blah>
 *     e.g. <action count msg:%1 can act %2 times this turn!>
 *     Assigns a custom action count message to this actor.
 *     This replaces the one defined in this plugin's parameter.
 *     Optional: use %1 = actor name, %2 = action count.
 * 
 *   Actor Notetag (use in an actor's notebox):
 *          <notify action count: x>
 *     e.g. <notify action count: 3>
 *     Assigns a custom "Notable Action Count" value to this actor.
 *     This affects when the action count message displays.
 *     It replaces the one defined in this plugin's parameter.
 * 
 *   For these tags:
 *     Replace 'blah' with the text you would like to use.
 *     Separate multiple values with a | character, e.g.
 *        <emerge:A screeching %1 approaches!|A %1 swoops down upon you!>
 *     Where multiple values exist, one will be chosen randomly.
 *     Blank custom emerge messages will be replaced with the default one.
 *     If the default is also blank, the message will not be shown.
 *
 *   Combining emerge-related tags:
 *     Tags are applied in this order:  <plural> --> <group> --> <emerge>
 *     I.e. names are merged into plurals,
 *          the group or troop name is identified, if appropriate,
 *          then the emerge message is displayed using that name.
 *     Group name, if defined, takes precedence over troop name.
 *     Default emerge message settings are configurable via plugin parameters.
 *
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
 * Terms of use:
 *   This plugin is free to use and/or modify, under these conditions:
 *     - None of the original plugin header is removed.
 *     - Credit is given to Caethyril for the original work.
 * 
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
 * Compatibility:
 *   Overrides: BattleManager:
 *                displayStartMessages
 *   Aliases:   Game_Troop:
 *                setup
 *              Window_BattleLog:
 *                displayAddedStates, displayRemovedStates
 *              Game_Actor:
 *                makeActions
 *   This plugin does not add data to save files.
 * 
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
 * Changelog:
 *   v1.0 (2020-08-21): Initial release! Rewrite of RMMV version.
 * 
 * @param --- Feature Select ---
 * @type select
 * @desc Choose which aspects of the plugin to enable.
 *
 * @param Emerge Features
 * @parent --- Feature Select ---
 * @type boolean
 * @desc If false, this plugin will not affect emerge messages.
 * @default false
 *
 * @param State Msg Features
 * @parent --- Feature Select ---
 * @type boolean
 * @desc If false, this plugin will not affect state messages.
 * @default false
 *
 * @param --- Emerge Options ---
 * @type select
 * @desc Configure the enemy emerge messages.
 *
 * @param Troop Name Emerge
 * @parent --- Emerge Options ---
 * @type combo
 * @option Always
 * @option Tagged troops only
 * @option Never
 * @desc When to use troop name in the emerge message.
 * The <group> tag takes precedence.
 * @default Tagged troops only
 *
 * @param Group Emerge Msg
 * @parent --- Emerge Options ---
 * @type string
 * @desc Default pattern for a <group> troop's emerge message.
 * Default: A %1 and its cohort appeared!
 * @default A %1 and its cohort appeared!
 *
 * @param Cull Duplicate Names
 * @parent --- Emerge Options ---
 * @type boolean
 * @desc If true, process one emerge message per unique enemy name.
 * Duplicate <plural> names will always be culled.
 * @default true
 *
 * @param --- Action Count Opts ---
 * @type select
 * @desc Configure this plugin's optional action count messages.
 * 
 * @param Action Count Message
 * @parent --- Action Count Opts ---
 * @type string
 * @desc Message shown when an actor has extra actions. %1 = actor name; %2 = action count. Blank messages are not shown.
 * @default %1 has %2 actions this turn!
 * 
 * @param Notable Action Count
 * @parent --- Action Count Opts ---
 * @type number
 * @desc Action Count Message will only show if an actor has at least this many actions on their turn.
 * @default 2
 * 
 * @param Action Count Msg Style
 * @parent --- Action Count Opts ---
 * @type combo
 * @option Message
 * @option BattleLog
 * @desc Determine where the action count message is shown.
 * BattleLog does not wait for input; Message does.
 * @default BattleLog
 * 
 * @param --- Advanced ---
 * @type select
 * @desc Advanced internal configuration options.
 *
 * @param Split Character
 * @parent --- Advanced ---
 * @type string
 * @desc The character used to split multiple possible messages.
 * Default: |
 * @default |
 * 
 * @param State ID Placeholder
 * @parent --- Advanced ---
 * @type string
 * @desc The character used to represent state ID in the custom state message notetags.
 * Default: #
 * @default #
 * 
 * @param Notetag: Group Emerge
 * @parent --- Advanced ---
 * @type string
 * @desc This tag's key/name.
 * Default: group
 * @default group
 *
 * @param Notetag: Troop Emerge Msg
 * @parent --- Advanced ---
 * @type string
 * @desc This tag's key/name.
 * Default: emerge
 * @default emerge
 *
 * @param Notetag: Preemptive Msg
 * @parent --- Advanced ---
 * @type string
 * @desc This tag's key/name.
 * Default: preemptive
 * @default preemptive
 *
 * @param Notetag: Surprise Msg
 * @parent --- Advanced ---
 * @type string
 * @desc This tag's key/name.
 * Default: surprise
 * @default surprise
 *
 * @param Notetag: Enemy Emerge Msg
 * @parent --- Advanced ---
 * @type string
 * @desc This tag's key/name.
 * Default: emerge
 * @default emerge
 *
 * @param Notetag: Plural Name
 * @parent --- Advanced ---
 * @type string
 * @desc This tag's key/name.
 * Default: plural
 * @default plural
 *
 * @param Notetag: Add State Msg
 * @parent --- Advanced ---
 * @type string
 * @desc This tag's key/name. Use # for the state ID.
 * Default: state # add msg
 * @default state # add msg
 *
 * @param Notetag: Remove State Msg
 * @parent --- Advanced ---
 * @type string
 * @desc This tag's key/name. Use # for the state ID.
 * Default: state # rem msg
 * @default state # rem msg
 * 
 * @param Notetag: Action Count Msg
 * @parent --- Advanced ---
 * @type string
 * @desc This tag's key/name.
 * Default: action count msg
 * @default action count msg
 * 
 * @param Notetag: Action Count Min
 * @parent --- Advanced ---
 * @type string
 * @desc This tag's key/name.
 * Default: notify action count
 * @default notify action count
 */
//#endregion

(function() {
'use strict';

    const NAMESPACE   = 'BattleMessages';
    const PLUGIN_NAME = 'Cae_' + NAMESPACE;
    const ERR_PRE     = PLUGIN_NAME + '.js ';
    const ERR_NOPARAM = ERR_PRE + 'could not find its parameters!\nCheck the plugin file is named correctly and try again.';
    const ERR_WATFORM = ERR_PRE + 'failed to parse %1 parameter value "%2".';

    window.CAE = window.CAE || {};      // Author namespace

    (($, U) => {

        Object.defineProperty($, 'VERSION', { value: 1.0 });    // Version declaration
        window.Imported = window.Imported || {};                // Import namespace
        Imported[PLUGIN_NAME] = $.VERSION;                      // Import declaration

        Object.defineProperty($, 'STYLE_EMERGE',    { value: ['always','tagged troops only','never'] });
        Object.defineProperty($, 'STYLE_ACTNUMMSG', { value: ['message','battlelog'] });

    // ======== Utility (share) ======== //

        void (k => { if (U[k]) return;
            /**
             * Counts number of occurrences of v in "this".
             * @param {String} v - Value to match against
             * @returns {Number} Number of occurrences.
             */
            U[k] = function(v) { return this.reduce(function(a, c) { return a += c === v ? 1 : 0; }, 0); };
        })('countMatch');

    // ======== Parameter stuff ======== //

        void (p => {

            if (!p) { SceneManager.showDevTools(); throw new Error(ERR_NOPARAM); };

            Object.defineProperty($, 'TAGSPLITTER',    { value: p['Split Character']      || '|' });
            Object.defineProperty($, 'STATEID_HOLDER', { value: p['State ID Placeholder'] || '#' });

            const WARN_TAG_FORBID  = ERR_PRE + 'character "%1" is forbidden in notetag keys.\n"%2" tag name will revert to default value: %3';
            const WARN_PARAM_STATE = ERR_PRE + 'state ID placeholder "' + $.STATEID_HOLDER + '" not found in %1 notetag pattern!';

            /**
             * Converts parameter key to lookup index.
             * @param {String} key - Plugin parameter key
             * @param {String[]} lookup - Array to use as lookup table
             * @returns {Number} Index of respective parameter value in lookup table.
             */
            $.parseComboSetting = function(key = '', lookup = []) {
                const value = p[key];
                const ix = lookup.indexOf(String(value || '').toLowerCase());
                if (ix < 0) console.error(ERR_WATFORM.format(key, value));
                return ix;
            };

            /**
             * Validates reference parameter value for use as a notetag key.
             * @param {String} key - Parameter key, e.g. 'Group Emerge'
             * @param {String} dFault - Default value, returned instead of unsuitable values
             * @param {String} req - Required string
             * @param {String} reqWarn - Warning message (console) shown if input does not contain req
             * @returns {String} Validated parameter value.
             */
            $.parseNotetagKey = function(key = '', dFault, req, reqWarn) {
                const res = p['Notetag: ' + key] || dFault;
                if (res.includes('>')) {
                    console.warn(WARN_TAG_FORBID.format('>', key, dFault));
                    return dFault;
                }
                if (req && !res.includes(req) && reqWarn) console.warn(reqWarn.format(key));
                return String(res).trim();
            };

            $.useEmerge    = p['Emerge Features'] === 'true';
            $.useStates    = p['State Msg Features'] === 'true';
            $.emergeStyle  = $.parseComboSetting('Troop Name Emerge', $.STYLE_EMERGE);
            $.grpEmergeMsg = p['Group Emerge Msg'] || '';
            $.dupeEmerge   = p['Cull Duplicate Names'] !== 'true';
            $.actNumMsg    = p['Action Count Message'];
            $.actNumMin    = parseInt(p['Notable Action Count'], 10) || 0;
            $.actCountType = $.parseComboSetting('Action Count Msg Style', $.STYLE_ACTNUMMSG);
            $.tags = {
                grpEmerge: $.parseNotetagKey('Group Emerge', 'group'),
                emergeMsg: $.parseNotetagKey('Troop Emerge Msg', 'emerge'),
                premptMsg: $.parseNotetagKey('Preemptive Msg', 'preemptive'),
                surprsMsg: $.parseNotetagKey('Surprise Msg', 'surprise'),
                nmeEmgMsg: $.parseNotetagKey('Enemy Emerge Msg', 'emerge'),
                pluralNom: $.parseNotetagKey('Plural Name', 'plural'),
                addStaMsg: $.parseNotetagKey('Add State Msg', 'state ' + $.STATEID_HOLDER + ' add msg', $.STATEID_HOLDER, WARN_PARAM_STATE),
                remStaMsg: $.parseNotetagKey('Remove State Msg', 'state ' + $.STATEID_HOLDER + ' rem msg', $.STATEID_HOLDER, WARN_PARAM_STATE),
                actNumMsg: $.parseNotetagKey('Action Count Msg', 'action count msg'),
                actNumMin: $.parseNotetagKey('Action Count Min', 'action count base')
            };

        })($.params = PluginManager.parameters(PLUGIN_NAME));

    // ========= Init Routines ========= //
    // ======== Utility (local) ======== //

        /**
         * @param {String} text - Input string
         * @returns {String} Random substring, split by the mighty tagsplitter (see Split Character parameter).
         */
        $.pickRandom = function(text) {
            const str = String(text).split($.TAGSPLITTER);
            return str[Math.randomInt(str.length)];
        };

        /**
         * Fetch the value of one of this plugin's notetags.
         * @param {Object} data - Database object with meta property 
         * @param {String} key - Notetag property key, e.g. grpEmerge
         * @returns {String} Object's notetag value, else empty string.
         */
        $.tagRaw = function(data, key = '') { return key ? data?.meta?.[key] || '' : ''; };

        /**
         * Return a random value from specified |-split notetag.
         * Intended for message-type tags, see plugin help section.
         * @param {Object} data - Database object with meta property
         * @param {String} key - Notetag property key, e.g. grpEmerge
         * @param {String} dFault - Default value, returned instead of an empty string
         * @returns {String} String from specified notetag.
         */
        $.tagString = function(data, key = '', dFault = '') {
            return $.pickRandom($.tagRaw(data, key)) || dFault;
        };

        /**
         * Assigns meta property to given troop object based on its name.
         * Used for extracting troop "name tags" like notetags.
         * @param {Game_Troop} troop - Game_Troop instance
         */
        $.troopMetaFromName = function(troop) {
            const dummy = { note: troop.name };             // Fake object for extraction
            DataManager.extractMetadata(dummy);             // Apply default method
            troop.meta = troop.meta || {};                  // Initialise meta property
            Object.keys(dummy.meta).forEach(function(m) {
                troop.meta[m] = dummy.meta[m];              // Transfer metadata
            });
            return !!dummy.meta;
        };

        /**
         * Returns troop's name minus the "name tags".
         * @param {Game_Troop} troop - Game_Troop instance
         * @returns {String} Troop name with <tags> removed.
         */
        $.troopNameWithoutTags = function(troop) {
            return troop.name.replace(/(<[^>]*>)/g, '').trim();
        };

        /**
         * Gets minimum "notable" action count value for given actor.
         * @param {Game_Actor} actor - Game_Actor instance
         * @returns {Number} Action count threshold for displaying message.
         */
        $.getActNumMin = function(actor) {
            const tag = parseInt($.tagRaw(actor.actor(), $.tags.actNumMin), 10);
            if (!tag || isNaN(tag)) return $.actNumMin;
            else return tag;
        };

        /**
         * Gets action count message for given actor.
         * @param {Game_Actor} actor - Game_Actor instance
         * @returns {String} Action count message.
         */
        $.getActNumMsg = function(actor) {
            return $.tagString(actor.actor(), $.tags.actNumMsg, $.actNumMsg);
        };

        /**
         * Returns list of name-ID pairs to use for emerge messages on battle start.
         * (Deliberately separate from the existing names and plural flags.)
         * @param {Game_Troop} troop - Game_Troop instance
         * @returns {{name:String,id:Number}[]} Array of enemy name and ID pairs.
         */
        $.emergeNames = function(troop) {
            const out = [], mem = [];
            const ENEMIES = troop.members().filter(m => m.isAlive());       // Get non-hidden, non-dead enemies
            const NAMES = ENEMIES.map(m => m.originalName());
            ENEMIES.forEach(nme => {
                const sMe = nme.originalName();                             // Get name as usual
                const seen = mem.includes(sMe);                             // Check if already seen this name
                if ($.dupeEmerge || !seen) {                                // Duplicate barrier
                    const tag = $.tagString(nme.enemy(), $.tags.pluralNom); // Get <plural> tag value
                    const acc = U.countMatch.call(NAMES, sMe);              // Count same-name non-hidden enemies
                    const plural = tag && acc > 1;                          // Non-hidden plural flag
                    const name = plural ? tag.format(acc) : sMe;            // Get name singular/plural as appropriate
                    const id = nme.enemyId();                               // Get enemy ID, for notetag retrieval
                    if (!seen || !plural) out.push({name:name,id:id});      // Not seen or not plural? Push to output!
                    mem.push(sMe);                                          // Do-once memory
                }
            });
            return out;
        };

        /**
         * @param {String[]} names - Array of enemy names
         * @param {Number} [index] - Index of leader (random if invalid or unspecified)
         * @returns {String} Name of group leader.
         */
        $.getGroupLeader = function(names, index) {
            let ix = index === true ? -1 : parseInt(index);
            if (isNaN(ix) || ix < 0 || ix >= names.length) {
                ix = Math.randomInt(names.length);
            }
            return names[ix].name;
        };

        // Message text generators
        $.mkMsg = {
            before: function(troop) { /** for modding */ },
            emerge: function(troop) {
                const troopName = $.troopNameWithoutTags(troop);
                const names     = $.emergeNames($gameTroop);
                const group     = $.tagString(troop, $.tags.grpEmerge);
                let   strE      = $.tagString(troop, $.tags.emergeMsg);
                const outE      = [];
                if (group) {
                    if (!strE) strE = $.grpEmergeMsg;
                    outE.push(strE.format($.getGroupLeader(names, group)));
                } else {
                    switch ($.emergeStyle) {
                        case 0:         // troop name
                            if (!strE) strE = TextManager.emerge;
                            // fall-through
                        case 1:         // troop name for tagged troops only
                            if (strE) {
                                outE.push(strE.format(troopName));
                                break;
                            } // else fall-through
                        default:        // battler names
                            if (!strE) strE = TextManager.emerge;
                            names.forEach(function(data) {
                                const nme = $dataEnemies[data.id];
                                const emg = $.tagString(nme, $.tags.nmeEmgMsg, strE);
                                outE.push(emg.format(data.name));
                            });
                    }
                }
                return outE;
            },
            special: function(troop) {
                const strP = $.tagString(troop, $.tags.premptMsg, TextManager.preemptive);
                const strS = $.tagString(troop, $.tags.surprsMsg, TextManager.surprise);
                if (BattleManager._preemptive && strP) {
                    return strP.format($gameParty.name());
                } else if (BattleManager._surprise && strS) {
                    return strS.format($gameParty.name());
                }
            },
            after: function(troop) { /** for modding */ },
            actNum: function(actor) {
                const count = actor.numActions();
                const min = $.getActNumMin(actor);
                const msg = $.getActNumMsg(actor);
                return count >= min ? msg.format(actor.name(), count) : '';
            }
        };

        /**
         * Shows a message!
         * @param {String} text - Message text
         * @param {Number} style - Determines how message is shown
         * - 0 = Window_Message (default)
         * - 1 = Window_BattleLog
         */
        $.showMsg = function(text = '', style = 0) {
            if (!text) return;
            if (Array.isArray(text)) text.forEach(s => $.showMsg(s, style));
            else switch (style) {
                case 1:  return BattleManager._logWindow.addText(text);
                default: return $gameMessage.add(text);
            }
        };

        // Methods for showing each of this plugin's message types
        $.show = {
            before:  function(troop) { $.showMsg($.mkMsg.before(troop)); },
            emerge:  function(troop) { $.showMsg($.mkMsg.emerge(troop)); },
            special: function(troop) { $.showMsg($.mkMsg.special(troop)); },
            after:   function(troop) { $.showMsg($.mkMsg.after(troop)); },
            actNum:  function(actor) { $.showMsg($.mkMsg.actNum(actor), $.actCountType); }
        };

        /**
         * @param {String} type - State action type: "add" or "rem"
         * @param {Number} id - State ID
         * @returns {String} Relevant notetag value.
         */
        $.tagKeyStateId = function(type, id) {
            return ($.tags[type + 'StaMsg'] || '').replace($.STATEID_HOLDER, id);
        };

        /**
         * @param {String} type - State action type: "add" or "rem"
         * @param {Boolean} isActor - True iff should get actor property
         * @returns {String} Relevant $dataStates message property name.
         */
        $.getStateMsgProp = function(type, isActor) {
            switch (type) {
                case 'add': return 'message' + (isActor ? '1' : '2');
                case 'rem': return 'message4';
                default:    return '';            // unknown
            }
        };

        /**
         * @param {String} type - State action type: "add" or "rem"
         * @param {Object} meta - Meta object = a database object's notetag values
         * @returns {Object[]} Array of $dataStates entries referenced by the notetags.
         */
        $.getTaggedStates = function(type, meta) {
            const out = [];
            for (let n = 1; n < $dataStates.length; n++) {        // Entry 0 is null >_>
                if (meta[$.tagKeyStateId(type, n)]) {
                    out.push($dataStates[n]);
                }
            }
            return out;
        };

        /**
         * Adjusts message values on appropriate $dataStates entries.
         * @param {String} type - State action type: "add" or "rem"
         * @param {Game_Actor|Game_Enemy} batt - A Game_Actor or Game_Enemy instance
         * @returns {{s:Object[],r:String[],p:String}} Memory object, used to restore default values afterwards
         * - s = states affected
         * - r = corresponding original values
         * - p = state message property that was altered
         */
        $.adjustStateMsgs = function(type, batt) {
            const isActor = batt.isActor();
            const daBatt  = isActor ? batt.actor() : batt.enemy();
            const prop    = $.getStateMsgProp(type, isActor);
            const states  = $.getTaggedStates(type, daBatt.meta);
            const mem     = [];
            if (prop && states.length > 0) {
                states.forEach(function(s) {
                    const p = $.tagKeyStateId(type, s.id);          // Get tag key
                    const str = $.tagString(daBatt, p, s[prop]);    // Get tag value (default is cheap but works)
                    mem.push(s[prop]);                              // Remember
                    s[prop] = str;                                  // Reassign
                });
                return { s: states, r: mem, p: prop };       // Used for restore
            }
            return;        // Unknown input
        };

        /**
         * Restores original $dataStates property values based on provided memory object.
         * @param {{s:Object[],r:String[],p:String}} o - Memory object
         */
        $.restoreStateMsgs = function(o) { if (o) o.s.forEach((s, n) => s[o.p] = o.r[n]); };

    // ============ Extends ============ //
    // ========== Alterations ========== //

        $.alias = $.alias || {};        // This plugin's alias namespace

        void (() => { if (!$.useEmerge) return;

            // Alias! Extract troop name tags on setup
            void (alias => {
                Game_Troop.prototype.setup = function(troopId) {
                    alias.apply(this, arguments);
                    $.troopMetaFromName(this.troop());
                };
            })($.alias.Game_Troop_setup = Game_Troop.prototype.setup);

            // Override! Custom message display routines~
            BattleManager.displayStartMessages = function() {
                const dataTroop = $gameTroop.troop();
                $.show.before(dataTroop);
                $.show.emerge(dataTroop);
                $.show.special(dataTroop);
                $.show.after(dataTroop);
            };

        })();

        void (() => { if (!$.useStates) return;

            // Alias! Adjust, display, then reset $dataStates message values.
            void (alias => {
                Window_BattleLog.prototype.displayAddedStates = function(target) {
                    const tmp = $.adjustStateMsgs('add', target);   // Change
                    alias.apply(this, arguments);
                    $.restoreStateMsgs(tmp);                        // Restore
                };
            })($.alias.Window_BattleLog_displayAddedStates = Window_BattleLog.prototype.displayAddedStates);

            // Alias! Adjust, display, then reset $dataStates message values.
            void (alias => {
                Window_BattleLog.prototype.displayRemovedStates = function(target) {
                    const tmp = $.adjustStateMsgs('rem', target);   // Change
                    alias.apply(this, arguments);
                    $.restoreStateMsgs(tmp);                        // Restore
                };
            })($.alias.Window_BattleLog_displayRemovedStates = Window_BattleLog.prototype.displayRemovedStates);

        })();

        // Alias! Check for displaying action count message.
        void (alias => {
            Game_Actor.prototype.makeActions = function() {
                alias.apply(this, arguments);
                $.show.actNum(this);
            };
        })($.alias.Game_Actor_makeActions = Game_Actor.prototype.makeActions);

    })(CAE[NAMESPACE] = CAE[NAMESPACE] || {}, CAE.Utils = CAE.Utils || {});

})();